#include <stdio.h>
#include <Windows.h>

/**
 * @brief
 *	GetProcAddressReplacement with forwarded function support. 
 *
 * @param hModule
 *	Module base address.
 *
 * @param lpApiName
 *	Function name to resolve
 *
 * @return
 *	resolved function pointer
 */
FARPROC GetProcAddressReplacementEx(
    IN HMODULE hModule,
    IN LPCSTR  lpApiName
) {
    // We do this to avoid casting at each time we use 'hModule'
    PBYTE pBase = (PBYTE)hModule;

    // Getting the dos header and doing a signature check
    PIMAGE_DOS_HEADER	pImgDosHdr = (PIMAGE_DOS_HEADER)pBase;
    if (pImgDosHdr->e_magic != IMAGE_DOS_SIGNATURE)
        return NULL;

    // Getting the nt headers and doing a signature check
    PIMAGE_NT_HEADERS	pImgNtHdrs = (PIMAGE_NT_HEADERS)(pBase + pImgDosHdr->e_lfanew);
    if (pImgNtHdrs->Signature != IMAGE_NT_SIGNATURE)
        return NULL;

    // Getting the optional header
    IMAGE_OPTIONAL_HEADER	ImgOptHdr = pImgNtHdrs->OptionalHeader;

    // Getting the image export table
    PIMAGE_EXPORT_DIRECTORY pImgExportDir = (PIMAGE_EXPORT_DIRECTORY)(pBase + ImgOptHdr.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);

    // Getting the export table size
    DWORD dwImgExportDirSize = ImgOptHdr.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size;

    // Getting the function's names array pointer
    PDWORD FunctionNameArray = (PDWORD)(pBase + pImgExportDir->AddressOfNames);

    // Getting the function's addresses array pointer
    PDWORD FunctionAddressArray = (PDWORD)(pBase + pImgExportDir->AddressOfFunctions);

    // Getting the function's ordinal array pointer
    PWORD  FunctionOrdinalArray = (PWORD)(pBase + pImgExportDir->AddressOfNameOrdinals);


    // Looping through all the exported functions
    for (DWORD i = 0; i < pImgExportDir->NumberOfFunctions; i++) {

        // Getting the name of the function
        CHAR* pFunctionName = (CHAR*)(pBase + FunctionNameArray[i]);

        // Getting the address of the function through its ordinal
        PVOID pFunctionAddress = (PVOID)(pBase + FunctionAddressArray[FunctionOrdinalArray[i]]);

        // Searching for the function specified
        if (strcmp(lpApiName, pFunctionName) == 0) {

            // check if the function is a forwarded function.
            if ( ( ( ( ULONG_PTR ) pFunctionAddress ) >= ( ( ULONG_PTR ) pImgExportDir ) ) && 
			     ( ( ( ULONG_PTR ) pFunctionAddress ) <  ( ( ULONG_PTR ) pImgExportDir ) + dwImgExportDirSize ) 
			) {
                CHAR  ForwarderName[ MAX_PATH ] = { 0 };
				DWORD DotOffset	   = 0;
				PCHAR FunctionMod  = NULL;
				PCHAR FunctionName = NULL;

				// save the forwarder string into our ForwarderName buffer 
				memcpy( ForwarderName, pFunctionAddress, strlen( ( PCHAR ) pFunctionAddress ) );
				
				// first find the offset of the dot '.'
				for ( int i = 0; i < strlen( ( PCHAR ) ForwarderName ); i++ ) 
				{
					// check for the '.'
				    if ( ( ( PCHAR ) ForwarderName )[ i ] == '.' )
				    {
						DotOffset = i;			   // save the dot offset/index 
						ForwarderName[ i ] = NULL; // replace the dot with a NULL terminator
				        break; 
				    }
				}

				FunctionMod  = ForwarderName;
				FunctionName = ForwarderName + DotOffset + 1;
				
				return GetProcAddressReplacementEx( LoadLibraryA( FunctionMod ), FunctionName );
			}

            return (FARPROC)pFunctionAddress;
        }
    }

    return NULL;
}


int main() {
    PVOID HeapAllocPtr = NULL;

    HeapAllocPtr = GetProcAddressReplacementEx( GetModuleHandleA( "Kernel32" ), "VirtualAlloc" );

    printf( "[ * ] CreateRemoteThread => %p\n", HeapAllocPtr );
}