# Forwarded Functions

In Module 53, IAT Hiding & Obfuscation - Custom GetProcAddress, it was shown how to write your own custom GetProcAddress function which resolves a function address based on a loaded module's address and function name string.

Although this module covers writing a reliable and well-implemented GetProcAddress function, there is a crucial missing feature which is very common in Windows when it comes to resolving a function.

The implemented GetProcAddress does not support "forwarded functions". Forwarded functions are exported function which are not truly implemented in the specified DLL and instead are simply forwarding to another DLL and function. 

# Forwarded Function Example

Let's take  HeapAlloc function as an example. In the official Microsoft documentation it tells us to load Kernel32 to use this function. But this function is also a forwarded function, which is generally identified in this format: Module.FunctionName. The module and name of where the original function is implemented are separated by a dot.

In this case, HeapAlloc is just a function forwarder that points to RtlAllocateHeap which is implemented inside ntdll 
(See image below: Ida freeware view exported functions  HeapAlloc inside of kernel32.dll)

# How to check if a function is a forwarded function or not?

When retrieving the function's address, check whether the address is in the export table address range (i.e. in the .text section). The reason being is that non-forwarded functions are pointer types, whereas forwarded functions are a string type and therefore would be found in the .rdata/.data sections.

# The challenge

If you have already completed Module 53 then you can try to solve this challenge by implementing forwarded function support into your custom GetProcAddress implementation.
I have listed resources relating to Forwarded Functions to help you and guide you.

Help!!

If you have any kind of questions or need help then feel free to ask questions in the challenges-discussion channel.

Have fun and happy hacking.

Resources: 
https://learn.microsoft.com/en-us/windows/win32/api/heapapi/nf-heapapi-heapalloc
https://devblogs.microsoft.com/oldnewthing/20060719-24/?p=30473
https://github.com/HavocFramework/Havoc/blob/dev/payloads/Demon/Source/Core/Win32.c#L409