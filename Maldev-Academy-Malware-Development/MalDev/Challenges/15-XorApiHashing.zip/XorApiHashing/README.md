For this week's challenge, we will be utilizing the `constexpr` feature to conduct compile-time hashing with obfuscation, ensuring that each time a string undergoes compile-time hashing, the resulting value will be distinct.

This can be accomplished by creating a function that computes a compile-time hash, followed by performing a bitwise XOR operation with a compile-time generated XOR key. The deobfuscation process will then take place during runtime.

This challenge will incorporate concepts that overlap with those introduced in module 57, specifically related to IAT Hiding & Obfuscation and Compile-Time API Hashing.