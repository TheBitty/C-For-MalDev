#include <Windows.h>
#include <stdio.h>

#define HASH_STR( x )  ( HashDeObf( ExprHashStringA( ( x ) ) ) )
#define H_MAGIC_KEY    5381

constexpr ULONG RandomCompileTimeSeed(
    void
) {
    return '0' * -40271 +
        __TIME__[7] * 1 +
        __TIME__[6] * 10 +
        __TIME__[4] * 60 +
        __TIME__[3] * 600 +
        __TIME__[1] * 3600 +
        __TIME__[0] * 36000;
};

// The compile time random seed
constexpr auto g_XorKey = RandomCompileTimeSeed() % 0xFFFF;


/*!
 * @brief
 *  Hashing ascii strings at compile time
 *
 * @param String
 *  Data/String to hash
 *
 * @param Length
 *  size of data/string to hash.
 *  if 0 then hash data til null terminator is found.
 *
 * @return
 *  hash of specified data/string
 */
constexpr ULONG ExprHashStringA(
    _In_ PCHAR String
) {
    ULONG Hash = 0;
    CHAR  Char = 0;

    Hash = H_MAGIC_KEY;

    if (!String) {
        return 0;
    }

    while ((Char = *String++)) {

        /* turn current character to uppercase */
        if (Char >= 'a') {
            Char -= 0x20;
        }

        Hash = ( ( Hash << 5 ) + Hash ) + Char;
    }

    return Hash ^ g_XorKey;
}

__declspec(noinline) ULONG HashDeObf(
    _In_ ULONG Hash
) {
    return Hash ^ g_XorKey;
}

int main() {
    printf( "[*] VirtualAllocEx Hash -> Obf:[%x] -> DeObf:[%x]\n", 
        ExprHashStringA( (PCHAR)"VirtualAllocEx" ), 
        HASH_STR( (PCHAR)"VirtualAllocEx" ) 
    );

    printf( "[*] NtAllocateVirtualMemory Hash -> Obf:[%x] -> DeObf:[%x]\n", 
        ExprHashStringA( (PCHAR)"NtAllocateVirtualMemory" ), 
        HASH_STR( (PCHAR)"NtAllocateVirtualMemory" ) 
    );
}