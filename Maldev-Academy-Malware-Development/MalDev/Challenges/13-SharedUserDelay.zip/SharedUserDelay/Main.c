#include "Header.h"

ULONG64 SharedTimestamp(
    VOID
) {
    LARGE_INTEGER Time = { 0 };

    Time.LowPart  = USER_SHARED_DATA->SystemTime.LowPart;
    Time.HighPart = USER_SHARED_DATA->SystemTime.High2Time;

    return Time.QuadPart;
}

VOID SharedSleep(
    _In_ ULONG64 Delay
) {
    SIZE_T  Rnd = { 0 };
    ULONG64 End = { 0 };

    Delay *= DELAY_TICKS;
    End    = SharedTimestamp() + Delay;

    /* increment random number til we reach the end */
    for ( Rnd = 0; SharedTimestamp() < End; Rnd++ );

    if ( ( SharedTimestamp() - End ) > 2000 ) {
        return;
    }
}

int main() {        
    printf( "[*] SharedSleep Delay [x05 @ Maldev Academy]\n" );

    printf( "[*] press enter to start to sleep for 10 seconds...");
    getchar();

    puts( "[*] Sleeping for 10 seconds" );
    SharedSleep( 10 * 1000 );
    puts( "[+] finished sleeping" );

    return 0;
}