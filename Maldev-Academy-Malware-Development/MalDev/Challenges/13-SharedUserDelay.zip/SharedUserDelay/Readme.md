**User Shared Data Delay**

In this week's challenge, we will be utilizing the `KUSER_SHARED_DATA` structure to delay the execution of our implant.

Many security products, including sandboxes, AVs, and EDRs often hook Sleep functions because these functions have historically been used in attempts to evade security measures. Rather than relying on these functions we will utilize the `KUSER_SHARED_DATA` structure, which is consistently located at a fixed memory address (0x7FFE0000). 

Within this structure, there is a member called `SystemTime` that receives frequent updates. We can leverage this member as a timestamp and effectively "wait" for our specified delay without triggering security product alarms.

Resources: 
- https://www.geoffchappell.com/studies/windows/km/ntoskrnl/inc/api/ntexapi_x/kuser_shared_data/index.htm
- https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntddk/ns-ntddk-kuser_shared_data
- https://shubakki.github.io/posts/2022/12/detecting-and-evading-sandboxing-through-time-based-evasion/