#include <Windows.h>
#include <immintrin.h>
#include <stdio.h>

ULONG RandomNumber32(
    VOID
) {
    ULONG Seed = 0;

    _rdrand32_step( &Seed );

    return Seed;
}

typedef struct
{
	DWORD	Length;
	DWORD	MaximumLength;
	PVOID	Buffer;

} USTRING;

typedef NTSTATUS(NTAPI* fnSystemFunction032)(
	struct USTRING* Data,
	struct USTRING* Key
);

BOOL Rc4EncryptionViaSystemFunc032(IN PBYTE pRc4Key, IN PBYTE pPayloadData, IN DWORD dwRc4KeySize, IN DWORD sPayloadSize) {

	NTSTATUS STATUS = NULL;

	USTRING Data = {
		.Buffer = pPayloadData,
		.Length = sPayloadSize,
		.MaximumLength = sPayloadSize
	};

	USTRING	Key = {
		.Buffer = pRc4Key,
		.Length = dwRc4KeySize,
		.MaximumLength = dwRc4KeySize
	};

	fnSystemFunction032 SystemFunction032 = (fnSystemFunction032)GetProcAddress(LoadLibraryA("Advapi32"), "SystemFunction032");

	if ((STATUS = SystemFunction032(&Data, &Key)) != 0x0) {
		printf("[!] SystemFunction032 FAILED With Error: 0x%0.8X \n", STATUS);
		return FALSE;
	}

	return TRUE;
}

/* credit: https://stackoverflow.com/questions/7775991/how-to-get-hexdump-of-a-structure-data */
void HexDump(
    const char* desc,
    const void* addr,
    const int   len
) {
    int i;
    int perLine = 8;
    unsigned char buff[9];
    const unsigned char* pc = (const unsigned char*)addr;

    if (desc != NULL) printf("%s:\n", desc);

    if (len == 0) {
        printf("  ZERO LENGTH\n");
        return;
    }
    if (len < 0) {
        printf("  NEGATIVE LENGTH: %d\n", len);
        return;
    }

    for (i = 0; i < len; i++) {
        if ((i % perLine) == 0) {
            if (i != 0) printf("  %s\n", buff);
            printf("  %04x ", i);
        }

        printf(" %02x", pc[i]);
        if ((pc[i] < 0x20) || (pc[i] > 0x7e))
            buff[i % perLine] = '.';
        else
            buff[i % perLine] = pc[i];
        buff[(i % perLine) + 1] = '\0';
    }

    while ((i % perLine) != 0) {
        printf("   ");
        i++;
    }

    printf("  %s\n", buff);
}


int main()
{
    BYTE BufferKey[ 16 ] = { 0 };
	CHAR BufferData[]	 = "5pider was here. yolo";

	/* generate a random key */
    for ( int i = 0; i < sizeof( BufferKey ); i++ ) {
        BufferKey[ i ] = RandomNumber32();
    }

    HexDump( "[*] BufferKey", BufferKey, sizeof(BufferKey) );
    HexDump( "[*] BufferData", BufferData, sizeof( BufferData ) );

    printf( "\n[*] Encrypt now...\n");
    Rc4EncryptionViaSystemFunc032( BufferKey, BufferData, sizeof( BufferKey ), sizeof( BufferData ) );
    
    HexDump( "[*] BufferData:", BufferData, sizeof( BufferData ) );
    printf("\n[*] Decrypt now...\n");

    Rc4EncryptionViaSystemFunc032( BufferKey, BufferData, sizeof( BufferKey ), sizeof( BufferData ) );
    HexDump( "[*] BufferData", BufferData, sizeof( BufferData ) );
}
