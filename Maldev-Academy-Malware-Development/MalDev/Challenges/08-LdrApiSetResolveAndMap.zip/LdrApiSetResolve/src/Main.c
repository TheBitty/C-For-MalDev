/*****************************************************************//**
 * \file   Main.c
 * \author 5pider
 * \date   September 2023
 *********************************************************************/

#include <Common.h>

#pragma comment( lib, "ntdll.lib" )

BOOL LdrResolveApiSet(
    WCHAR ModuleApiSet[ MAX_PATH ],
    WCHAR ModuleAlias [ MAX_PATH ]
);

PVOID LdrMapModule(
    _In_ LPWSTR ModuleName
);

/**
 * @brief
 *  windows main entry point
 */
int main(
    void
) {
    WCHAR  ModuleAlias[ MAX_PATH ] = { 0 };
    PWCHAR ApiSetModule            = NULL;
    PVOID  Module                  = NULL;

    RtlSecureZeroMemory( ModuleAlias, sizeof( ModuleAlias ) ); 

    ApiSetModule = L"api-ms-win-base-util-l1-1-0"; 
    if ( LdrResolveApiSet( ApiSetModule, ModuleAlias ) ) {
        printf( "[*] %ls -> %ls\n", ApiSetModule, ModuleAlias );
    } else {
        printf( "[-] failed to resolve api set %ls\n", ApiSetModule );
        goto END;
    }

    /* trying to manually map module */
    if ( ( Module = LdrMapModule( ModuleAlias ) ) ) {
        printf( "[+] successfully mapped %ls into memory @ %p\n", ModuleAlias, Module );
    } else {
        printf( "[-] failed to map %ls into memory", ModuleAlias );
    }

    getchar();

END:
    return 0;
}

/**
 * @brief
 *  resolves an api set alias
 *
 * @param ModuleApiSet
 *  module api set to resolve
 *
 * @param ModuleAlias
 *  resolved module alias
 *
 * @return BOOL
 *  if successful resolved api set
 */
BOOL LdrResolveApiSet(
    WCHAR ModuleApiSet[ MAX_PATH ],
    WCHAR ModuleAlias [ MAX_PATH ]
) {
    BOOL                     Success       = FALSE;
    PPEB                     Peb           = NULL;
    PAPI_SET_NAMESPACE       ApiMap        = NULL;
    PAPI_SET_NAMESPACE_ENTRY ApiMapEntry   = NULL;
    PAPI_SET_VALUE_ENTRY     ApiValueEntry = NULL;
    PWCHAR                   ApiStrName    = { 0 };
    UNICODE_STRING           ApiStrValue   = { 0 };

    if ( ! ModuleApiSet || ! ModuleAlias ) {
        return FALSE;
    }

    /* get PEB.ApiSetMap to iterate over it */
    Peb         = NtCurrentPeb();
    ApiMap      = Peb->ApiSetMap;
    ApiMapEntry = C_PTR( U_PTR( ApiMap->EntryOffset + U_PTR( ApiMap ) ) );

    /* iterate over the api set map */
    for ( ULONG i = 0; i < ApiMap->Count; i++ ) {

        ApiStrName = C_PTR( U_PTR( ApiMap + U_PTR( ApiMapEntry->NameOffset ) ) );

        /* is it our api set name */ 
        if ( wcscmp( ApiStrName, ModuleApiSet ) == 0 ) {

            /* get value entry pointer & alias string */
            ApiValueEntry = C_PTR( U_PTR( ApiMap + ApiMapEntry->ValueOffset   ) );
            ApiStrName    = C_PTR( U_PTR( ApiMap + ApiValueEntry->ValueOffset ) );

            /* copy over the alias name */
            memcpy( ModuleAlias, ApiStrName, ApiValueEntry->ValueLength > MAX_PATH ? MAX_PATH : ApiValueEntry->ValueLength );

            /* tell that we were successful */
            Success = TRUE; 
            
            break; 
        }

        /* next entry */
        ApiMapEntry++;
    }

    return Success;
}

/**
 * @brief
 *  map module from disk into memory
 *
 * @param Name
 *  name of module to map
 *
 * @return
 *  return mapped module handle
 */
PVOID LdrMapModule(
    _In_ LPWSTR Name
) {
    PVOID             Module           = { 0 };
    HANDLE            File             = { 0 };
    HANDLE            Section          = { 0 };
    UNICODE_STRING    FilePath         = { 0 };
    OBJECT_ATTRIBUTES ObjAttr          = { 0 };
    IO_STATUS_BLOCK   IoBlock          = { 0 };
    WCHAR             Path[ MAX_PATH ] = { 0 };
    SIZE_T            Length           = { 0 };
    SIZE_T            Size             = { 0 };
    NTSTATUS          Status           = STATUS_SUCCESS;
    WCHAR             System[]         = L"\\??\\C:\\Windows\\System32\\";

    /* zero memory the structs */
    MemZero( &Path,     sizeof( Path     ) );
    MemZero( &FilePath, sizeof( FilePath ) );
    MemZero( &ObjAttr,  sizeof( ObjAttr  ) );

    /* get given module name size */
    Size = wcslen( Name );

    /* create path to load from ex. \??\C:\Windows\System32\Module.dll */
    Size = Size * sizeof( WCHAR );
    memcpy( Path, System, LDR_SYSTEM32_PATH_SIZE );
    memcpy( ( U_PTR( Path ) + LDR_SYSTEM32_PATH_SIZE ), Name, Size );
    Length = LDR_SYSTEM32_PATH_SIZE + Size;

    /* create unicode string */
    FilePath.Length        =  FilePath.MaximumLength = Length;
    FilePath.MaximumLength += sizeof( WCHAR );
    FilePath.Buffer        =  Path;

    /* init object attributes */
    InitializeObjectAttributes(
        &ObjAttr,
        &FilePath,
        OBJ_CASE_INSENSITIVE,
        NULL,
        NULL
    );

    /* open module/dll file */
    if ( ! NT_SUCCESS( Status = NtOpenFile(
        &File,
        FILE_GENERIC_READ | FILE_GENERIC_EXECUTE,
        &ObjAttr,
        &IoBlock,
        FILE_SHARE_READ,
        0
    ) ) ) {
        printf( "[-] NtOpenFile failed: %p\n", Status );
        goto END;
    }

    /* create section from file handle */
    if ( ! NT_SUCCESS( Status = NtCreateSection(
        &Section,
        SECTION_ALL_ACCESS,
        NULL,
        NULL,
        PAGE_EXECUTE,
        SEC_IMAGE,
        File
    ) ) ) {
        printf( "[-] NtCreateSection failed: %p\n", Status );
        goto END;
    }

    Length = 0;

    /* map section */
    if ( ! NT_SUCCESS( Status = NtMapViewOfSection(
        Section,
        NtCurrentProcess(),
        &Module,
        0,
        0,
        NULL,
        &Length,
        ViewUnmap,
        0,
        PAGE_READONLY
    ) ) ) {
        printf( "[-] NtMapViewOfSection failed: %p\n", Status );
        goto END;
    }

END:
    /* close section handle */
    if ( File ) {
        NtClose( File );
        File = NULL;
    }

    /* close section handle */
    if ( Section ) {
        NtClose( Section );
        Section = NULL;
    }

    MemZero( System, sizeof( System ) );

    return Module;
}
