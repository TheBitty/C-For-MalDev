**Shellcoding: Stage & Remote Inject**

In this week's challenge, we will be taking a look at writing a custom shellcode stager that is going to inject our payload into a remote process which in this case is going to be explorer.exe. 

**The Challenge**

Try to write a shellcode binary that retrieve our payload from a specific server endpoint and inject the payload in the remote process (explorer.exe) using module stomping. 

As usual, use the #challenges-discussion channel to discuss the challenge or request help.

**__Have fun and happy hacking.__ **

**Usage**

To simply build this project you simply need to type `make` into the terminal. 
After that the compiled binary shellcode is saved as `shellcode.bin` which is ready to use.
It is requiered to change the address where the shellcode is going to pull/stage the shellcode from under `shellcode.c:54`. The stager expects an raw binary to be hosted on a http server under the port `8000` (can be a python server like `python -m http.server`) on the endpoint `payload.bin` (e.g: `http://127.0.0.1:8000/payload.bin`). 