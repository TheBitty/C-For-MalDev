// @NUL0x4C | @mrd0x : MalDevAcademy

#include <Windows.h>


extern __declspec(dllexport) void  NetScheduleJobGetInfo() {
}

extern __declspec(dllexport) void  NetScheduleJobAdd() {
}

extern __declspec(dllexport) void  NetScheduleJobDel() {
}

extern __declspec(dllexport) void  NetScheduleJobEnum() {
    MessageBoxA(NULL, "This DLL is Side-Loaded!", "Success!", MB_OK | MB_ICONEXCLAMATION);
}



BOOL APIENTRY DllMain(HMODULE hModule, DWORD dwReason, LPVOID lpReserved) {

    switch (dwReason)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
