**Compile time string encryption** 

In this week's challenge, we will be using constexpr to perform compile-time string encryption and decrypt the string at runtime, all while generating a random encryption key at compile time. Encrypting strings at compile time and decrypting them at runtime allows implants to conceal important strings and data from security products that have specific signatures designed to detect such strings.

This challenge will encompass concepts that were previously introduced in Module 57 (IAT Hiding & Obfuscation - Compile Time API Hashing).

Resources: 
- https://gist.github.com/EvanMcBroom/ace2a9af19fb5e7b2451b1cd4c07bf96