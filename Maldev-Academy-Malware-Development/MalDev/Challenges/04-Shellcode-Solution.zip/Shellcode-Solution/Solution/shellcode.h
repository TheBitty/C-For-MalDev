#ifndef SHELLCODE_H
#define SHELLCODE_H 

/* local headers */
#include "Native.h"

/* casting */
#define C_PTR( x ) ( ( PVOID )    x )
#define U_PTR( x ) ( ( UINT_PTR ) x )

/* Modules */
#define H_MODULE_NTDLL    ( 0x70e61753 )
#define H_MODULE_KERNEL32 ( 0xadd31df0 )

/* Functionns */
#define H_API_WINEXEC     ( 0xdcbda5d8 )

VOID Main(
  VOID
);

PVOID LdrModulePeb(
  _In_ ULONG Hash
);

PVOID LdrFunctionAddr(
  _In_ PVOID Module,
  _In_ ULONG Function
);

#endif // SHELLCODE_H
