The project has been written using x64_86 mingw compiler so it might not work under visual studio. Be aware of that. 

Small notes on the files:
- Native.h: a header file that contains some windows internals structure which should be valid in modern windows versions (contains fully documented PEB struct, etc.)
- extract.py: extracts the "shellcode" from the compiled executable by parsing the PE file and dumps the .text section into the shellcode.bin file
- hash.py: a small script that generates a function hash (use: python hash.py WinExec)
- makefile: a makefile that auto generates the shellcode for you so no need to do anything else besides modifying the shellcode.c file.
- shellcode.c: source code of the shellcode
- shellcode.h: header file of for the shellcode.c file