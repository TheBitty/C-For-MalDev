#include <Windows.h>
#include <stdio.h>

#define HASH_STR( x )  ( HashDeObf( ExprHashStringA( ( x ) ) ) )
#define H_MAGIC_KEY    5381
#define C_PTR( x )      ( ( PVOID ) x )
#define U_PTR( x )      ( ( ULONG_PTR ) x )

constexpr ULONG RandomCompileTimeSeed(
    void
) {
    return '0' * -40271 +
        __TIME__[7] * 1 +
        __TIME__[6] * 10 +
        __TIME__[4] * 60 +
        __TIME__[3] * 600 +
        __TIME__[1] * 3600 +
        __TIME__[0] * 36000;
};

// The compile time random seed
constexpr auto g_XorKey = RandomCompileTimeSeed() % 0xFFFF;

/*!
 * @brief
 *  Hashing ascii strings at compile time
 *
 * @param String
 *  Data/String to hash
 *
 * @param Length
 *  size of data/string to hash.
 *  if 0 then hash data til null terminator is found.
 *
 * @return
 *  hash of specified data/string
 */
constexpr ULONG ExprHashStringA(
    _In_ PCHAR String
) {
    ULONG Hash = 0;
    CHAR  Char = 0;

    Hash = H_MAGIC_KEY;

    if (!String) {
        return 0;
    }

    while ((Char = *String++)) {

        /* turn current character to uppercase */
        if (Char >= 'a') {
            Char -= 0x20;
        }

        Hash = ( ( Hash << 5 ) + Hash ) + Char;
    }

    return Hash ^ g_XorKey;
}

__declspec(noinline) ULONG HashDeObf(
    _In_ ULONG Hash
) {
    return Hash ^ g_XorKey;
}

/**
 * @brief
 *	GetProcAddressReplacement while using obfuscated hashes
 *
 * @param hModule
 *	Module base address.
 *
 * @param lpApiName
 *	Function name to resolve
 *
 * @return
 *	resolved function pointer
 */
PVOID GetProcAddressReplacementEx(
    _In_ PVOID hModule,
    _In_ ULONG Hash
) {
    // We do this to avoid casting at each time we use 'hModule'
    PBYTE pBase = (PBYTE)hModule;

    // Getting the dos header and doing a signature check
    PIMAGE_DOS_HEADER	pImgDosHdr = (PIMAGE_DOS_HEADER)pBase;
    if (pImgDosHdr->e_magic != IMAGE_DOS_SIGNATURE)
        return NULL;

    // Getting the nt headers and doing a signature check
    PIMAGE_NT_HEADERS	pImgNtHdrs = (PIMAGE_NT_HEADERS)(pBase + pImgDosHdr->e_lfanew);
    if (pImgNtHdrs->Signature != IMAGE_NT_SIGNATURE)
        return NULL;

    // Getting the optional header
    IMAGE_OPTIONAL_HEADER	ImgOptHdr = pImgNtHdrs->OptionalHeader;

    // Getting the image export table
    PIMAGE_EXPORT_DIRECTORY pImgExportDir = (PIMAGE_EXPORT_DIRECTORY)(pBase + ImgOptHdr.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);

    // Getting the export table size
    DWORD dwImgExportDirSize = ImgOptHdr.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size;

    // Getting the function's names array pointer
    PDWORD FunctionNameArray = (PDWORD)(pBase + pImgExportDir->AddressOfNames);

    // Getting the function's addresses array pointer
    PDWORD FunctionAddressArray = (PDWORD)(pBase + pImgExportDir->AddressOfFunctions);

    // Getting the function's ordinal array pointer
    PWORD  FunctionOrdinalArray = (PWORD)(pBase + pImgExportDir->AddressOfNameOrdinals);


    // Looping through all the exported functions
    for (DWORD i = 0; i < pImgExportDir->NumberOfFunctions; i++) {

        // Getting the name of the function
        CHAR* pFunctionName = (CHAR*)(pBase + FunctionNameArray[i]);

        // Getting the address of the function through its ordinal
        PVOID pFunctionAddress = (PVOID)(pBase + FunctionAddressArray[ FunctionOrdinalArray[ i ] ] );

        // Searching for the function specified
        if ( HashDeObf( ExprHashStringA( pFunctionName ) ) == Hash ) {
            return (FARPROC)pFunctionAddress;
        }
    }

    return NULL;
}

int main() {
   
    printf( 
        "[*] NtAllocateVirtualMemory:\n"
        "     - Hash    -> Obf:[%x] -> DeObf:[%x]\n"
        "     - Pointer @ %p\n", 
        ExprHashStringA( (PCHAR)"NtAllocateVirtualMemory" ), 
        HASH_STR( (PCHAR)"NtAllocateVirtualMemory" ),
        GetProcAddressReplacementEx( GetModuleHandleA( "ntdll.dll" ), HASH_STR( (PCHAR)"NtAllocateVirtualMemory" ) )
    );

}