/*****************************************************************//**
 * \file   Main.c
 * \author 5pider
 * \date   August 2023
 *********************************************************************/

#include <Common.h>

BOOL LdrResolveApiSet(
    WCHAR ModuleApiSet[ MAX_PATH ],
    WCHAR ModuleAlias [ MAX_PATH ]
);

/**
 * @brief
 *  windows main entry point
 */
int main(
    void
) {
    WCHAR  ModuleAlias[ MAX_PATH ] = { 0 };
    PWCHAR ApiSetModule            = NULL;

    RtlSecureZeroMemory( ModuleAlias, sizeof( ModuleAlias ) ); 

    ApiSetModule = L"api-ms-win-base-util-l1-1-0"; 
    if ( LdrResolveApiSet( ApiSetModule, ModuleAlias ) ) {
        printf( "[*] %ls -> %ls\n", ApiSetModule, ModuleAlias );
    }

    RtlSecureZeroMemory( ModuleAlias, sizeof( ModuleAlias ) ); 

    ApiSetModule = L"api-ms-win-core-com-l1-1-3"; 
    if ( LdrResolveApiSet( ApiSetModule, ModuleAlias ) ) {
        printf( "[*] %ls -> %ls\n", ApiSetModule, ModuleAlias );
    }

    RtlSecureZeroMemory( ModuleAlias, sizeof( ModuleAlias ) ); 

    ApiSetModule = L"api-ms-win-core-crt-l1-1-0"; 
    if ( LdrResolveApiSet( ApiSetModule, ModuleAlias ) ) {
        printf( "[*] %ls -> %ls\n", ApiSetModule, ModuleAlias );
    }

    RtlSecureZeroMemory( ModuleAlias, sizeof( ModuleAlias ) ); 

    ApiSetModule = L"api-ms-win-ole32-ie-l1-1-0"; 
    if ( LdrResolveApiSet( ApiSetModule, ModuleAlias ) ) {
        printf( "[*] %ls -> %ls\n", ApiSetModule, ModuleAlias );
    }

    return 0;
}

/**
 * @brief
 *  resolves an api set alias
 *
 * @param ModuleApiSet
 *  module api set to resolve
 *
 * @param ModuleAlias
 *  resolved module alias
 *
 * @return BOOL
 *  if successful resolved api set
 */
BOOL LdrResolveApiSet(
    WCHAR ModuleApiSet[ MAX_PATH ],
    WCHAR ModuleAlias [ MAX_PATH ]
) {
    BOOL                     Success       = FALSE;
    PPEB                     Peb           = NULL;
    PAPI_SET_NAMESPACE       ApiMap        = NULL;
    PAPI_SET_NAMESPACE_ENTRY ApiMapEntry   = NULL;
    PAPI_SET_VALUE_ENTRY     ApiValueEntry = NULL;
    PWCHAR                   ApiStrName    = { 0 };
    UNICODE_STRING           ApiStrValue   = { 0 };

    if ( ! ModuleApiSet || ! ModuleAlias ) {
        return FALSE;
    }

    /* get PEB.ApiSetMap to iterate over it */
    Peb         = NtCurrentPeb();
    ApiMap      = Peb->ApiSetMap;
    ApiMapEntry = C_PTR( U_PTR( ApiMap->EntryOffset + U_PTR( ApiMap ) ) );

    /* iterate over the api set map */
    for ( ULONG i = 0; i < ApiMap->Count; i++ ) {

        ApiStrName = C_PTR( U_PTR( ApiMap + U_PTR( ApiMapEntry->NameOffset ) ) );

        /* is it our api set name */ 
        if ( wcscmp( ApiStrName, ModuleApiSet ) == 0 ) {

            /* get value entry pointer & alias string */
            ApiValueEntry = C_PTR( U_PTR( ApiMap + ApiMapEntry->ValueOffset   ) );
            ApiStrName    = C_PTR( U_PTR( ApiMap + ApiValueEntry->ValueOffset ) );

            /* copy over the alias name */
            memcpy( ModuleAlias, ApiStrName, ApiValueEntry->ValueLength > MAX_PATH ? MAX_PATH : ApiValueEntry->ValueLength );

            /* tell that we were successful */
            Success = TRUE; 
            
            break; 
        }

        /* next entry */
        ApiMapEntry++;
    }

    return Success;
}