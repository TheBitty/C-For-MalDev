#include <Windows.h>
#include <ntstatus.h>
#include <stdio.h>

#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)

typedef NTSTATUS( NTAPI* SYSTEMFUNCTION04041 )(
    _Inout_ PVOID Memory,
    _In_    ULONG Size,
    _In_    ULONG Flags
);

NTSTATUS x05SystemFunction040(
    _Inout_ PVOID Memory,
    _In_    ULONG Size,
    _In_    ULONG Flags
) {
    SYSTEMFUNCTION04041 Sys040 = NULL;

    Sys040 = ( SYSTEMFUNCTION04041 ) GetProcAddress( LoadLibraryA( "Advapi32" ), "SystemFunction040" );
    if ( ! Sys040 ) {
        return STATUS_INVALID_ADDRESS;
    }

    return Sys040( Memory, Size, Flags );
}

NTSTATUS x05SystemFunction041(
    _Inout_ PVOID Memory,
    _In_    ULONG Size,
    _In_    ULONG Flags
) {
    SYSTEMFUNCTION04041 Sys041 = NULL;

    Sys041 = ( SYSTEMFUNCTION04041 ) GetProcAddress( LoadLibraryA( "Advapi32" ), "SystemFunction041" );
    if ( ! Sys041 ) {
        return STATUS_INVALID_ADDRESS;
    }

    return Sys041( Memory, Size, Flags );
}

/* credit: https://stackoverflow.com/questions/7775991/how-to-get-hexdump-of-a-structure-data */
void HexDump(
    const char* desc,
    const void* addr,
    const int   len
) {
    int i;
    int perLine = 8;
    unsigned char buff[9];
    const unsigned char* pc = (const unsigned char*)addr;

    if (desc != NULL) printf("%s:\n", desc);

    if (len == 0) {
        printf("  ZERO LENGTH\n");
        return;
    }
    if (len < 0) {
        printf("  NEGATIVE LENGTH: %d\n", len);
        return;
    }

    for (i = 0; i < len; i++) {
        if ((i % perLine) == 0) {
            if (i != 0) printf("  %s\n", buff);
            printf("  %04x ", i);
        }

        printf(" %02x", pc[i]);
        if ((pc[i] < 0x20) || (pc[i] > 0x7e))
            buff[i % perLine] = '.';
        else
            buff[i % perLine] = pc[i];
        buff[(i % perLine) + 1] = '\0';
    }

    while ((i % perLine) != 0) {
        printf("   ");
        i++;
    }

    printf("  %s\n", buff);
}

int main()
{
    CHAR     String[] = "5pider was here. yolo";
    NTSTATUS Status   = STATUS_SUCCESS;
    PVOID    Memory   = NULL;
    ULONG    Size     = 32;

    if ( ! ( Memory = HeapAlloc( GetProcessHeap(), HEAP_ZERO_MEMORY, Size ) ) ) {
        printf( "[-] HeapAlloc failed: %x\n", GetLastError() );
        return 0; 
    }

    /* copy over the string into the allocate space */
    memcpy( Memory, String, sizeof( String ) );

    HexDump( "[*] Memory", Memory, sizeof( String ) );

    /* encrypt data using SystemFunction040 */
    printf( "\n[*] Encrypt now...\n" );
    Status = x05SystemFunction040( Memory, Size, 0 );
    if ( ! NT_SUCCESS( Status ) ) {
        printf( "[-] SystemFunction040 Failed: %p\n", Status );
        return 0; 
    }

    HexDump( "[*] Memory:", Memory, sizeof( String ) );

    /* decrypt data using SystemFunction040 */
    printf("\n[*] Decrypt now...\n");
    Status = x05SystemFunction041( Memory, Size, 0 );
    if ( ! NT_SUCCESS( Status ) ) {
        printf( "[-] SystemFunction041 Failed: %p\n", Status );
        return 0; 
    }

    HexDump( "[*] Memory", Memory, sizeof( String ) );
}

